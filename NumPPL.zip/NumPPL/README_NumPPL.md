# NumPPL

Numeric functions over Storage arrays (NumPy style). Same structure as StorageLib:
logic lives in the `FuncX` methods, arguments are read with `ExtractEvaluatedParamsForLibrary`,
arrays are PPL Storages (`storage a[2,3];`). No own array type, no Vector/Matrix.

Functions that already exist are **not** repeated: use `Math.*` (Abs, Sqrt, Exp, Log, Sin, Cos, ...),
`storage.*` (Sum, Min, Max, Average, Product, Median, Sort, Copy, ...) and `Random.*`.

## Files
| File | Purpose |
|---|---|
| `NumPPL.cfg` | CodeGen config (26 methods) |
| `NumPPL.h`, `NumPPL.cpp` | the library (CodeGen skeleton with the logic written in) |
| `tests/test_numppl.cpp`, `tests/run_tests.sh` | tests of the real `NumPPL.cpp` against stubs of the PPL headers |
| `tests/stub/` | test stubs of `PPL.h`, `Component.h`, `Processing.h` (only for the tests, not part of the library) |
| `examples/numppl_basic.scr` | example script |

## Rules
* The destination is always the **last** argument. It must exist (`storage r;` first) and is replaced completely.
  A source may be the destination.
* An operand of `Add, Sub, Mul, Div, Pow, Clip, Dot, Solve` is a storage or a number (or a variable holding a number).
* Whole storages only (no `s[1]` sub-array sources). Storages must be rectangular and numeric.
* Broadcasting as in NumPy: shapes are aligned from the right, an axis of size 1 stretches.
* Statistics (`Var, Std, ArgMin, ArgMax, Norm`) work on all values; the result goes to a variable.
* Errors: `printDlgt({"Error: [NumPPL.X] ..."})` and `return false`, as in StorageLib.
* Numbers are written with the shortest text that reads back to the same double (`0.1`, `1e-07`, `inf`, `nan`).

## Methods
| Call | What it does |
|---|---|
| `NumPPL.Zeros(d1)[(d2)...](dst)` | array of 0 |
| `NumPPL.Ones(d1)[(d2)...](dst)` | array of 1 |
| `NumPPL.Full(value)(d1)[(d2)...](dst)` | array of value |
| `NumPPL.Eye(n)[(m)](dst)` | identity matrix |
| `NumPPL.Arange(start)(stop)[(step)](dst)` | start, start+step, ... below stop |
| `NumPPL.Linspace(start)(stop)(num)(dst)` | num values, both ends included |
| `NumPPL.Reshape(src)(d1)[(d2)...](dst)` | new shape (one dim may be -1) |
| `NumPPL.Transpose(src)(dst)` | reverses the axes |
| `NumPPL.Add/Sub/Mul/Div/Pow(a)(b)(dst)` | element-wise with broadcasting |
| `NumPPL.Clip(a)(lo)(hi)(dst)` | limits values to [lo, hi] |
| `NumPPL.Var/Std(src)(var)` | population variance / standard deviation |
| `NumPPL.ArgMin/ArgMax(src)(var)` | flat index of the first min / max |
| `NumPPL.CumSum(src)(dst)` | running sum over the flattened array |
| `NumPPL.ArgSort(src)(dst)` | flat indices in ascending order (stable, NaN last) |
| `NumPPL.Dot(a)(b)(dst)` | vector.vector -> variable; matrix.matrix, matrix.vector, vector.matrix -> storage |
| `NumPPL.Det(a)(var)` | determinant (0 for a singular matrix) |
| `NumPPL.Inv(a)(dst)` | inverse (error if singular) |
| `NumPPL.Solve(a)(b)(dst)` | solves a x = b, b vector or matrix |
| `NumPPL.Trace(a)(var)` | sum of the main diagonal |
| `NumPPL.Norm(a)(var)` | Euclidean (Frobenius) norm |

## Building
C++23 is required (`std::expected`, multidimensional `operator[]`, `std::ranges`):
g++ 13+ (`-std=c++23`) or MSVC `/std:c++latest`. Add `NumPPL` to the DLL project like StorageLib and
`(UserImportN [NumPPL])` to Configuration.data.

## Verification status
* `tests/run_tests.sh`: 155 checks, g++ 13.3, `-Wall -Wextra`, AddressSanitizer + UBSan: all pass.
* The tests compile the real `NumPPL.cpp` against **stubs** written from the `Component.h` and `Processing.h` you sent.
  PPL.h and pch.h were not available, so the real build and the real interpreter are untested.

## Assumptions to check on the first real build
1. `StorageComponent::SetRoot(StorageNode&&)` replaces the tree and refreshes the cached dimension count.
2. `StorageComponent::GetDimSize(const vector<int>& path)` returns the number of children of the node at `path`
   (an empty path = the root).
3. A storage name passed as argument 2, 3, ... keeps its name in `raw` (`Operand()` looks it up there first).
4. `GetValueFromParameters` evaluates a variable to its value, a number stays as text.
