#ifndef PCH_H
#define PCH_H

// add headers that you want to pre-compile here
#include <iostream>
#include <cassert>
#include <format>
#include <string>
#include <sstream>
#include <cstdarg>
#include <iterator>
#include <list>
#include <typeinfo>
#include <stack>
#include <unordered_map>
#include <map>
#include <vector>
#include <fstream>
#include <direct.h>
#include <exception>
#include <thread>
#include <chrono>
#include <algorithm>
#include <filesystem>
#include <iomanip>
#include <cstdlib>
#include <numeric>
#include "framework.h"
#include <Windows.h>
#include <cmath>
#include <functional>
//#include <execution>

#include <mutex>
#include <condition_variable>
#include <queue>
#endif //PCH_H

