// NumPPL: numeric functions over Storage arrays (NumPy style).
// Same structure as StorageLib: arguments are read with ExtractEvaluatedParamsForLibrary,
// the source Storage is read into a dense array, the result is written to a destination
// Storage (or a variable for scalar results). Destination is always the LAST argument.
// Needs C++23 (std::expected): /std:c++latest for MSVC, -std=c++23 for GCC 13+.
#include "pch.h"
// This file is compiled only into NumPPL.dll, so the API must always be exported
// (import-by-name needs the symbol NumPPL_CreateInstance in the DLL, see Processing::FuncImport).
#ifndef NUMPPL_EXPORTS
#define NUMPPL_EXPORTS
#endif
#include "../PPL/PPL.h"
#include "../PPL/Component/Component.h"
#include "../PPL/Processing/Processing.h"
#include "NumPPL.h"
#include <algorithm>
#include <charconv>
#include <cmath>
#include <cctype>
#include <limits>
#include <numeric>
#include <ranges>

using namespace std;

namespace PPLNS
{
  static NumPPL* NUMPPLInstance = nullptr;

  void NumPPL_CreateInstance(PPL* ppl)
  {
    NUMPPLInstance = new NumPPL(ppl);
    NUMPPLInstance->AddToKeywordDictionary();
  }

  NumPPL::NumPPL(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }

  //=======================================================
  void NumPPL::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Zeros", FuncZeros);
    AddKeyword("Ones", FuncOnes);
    AddKeyword("Full", FuncFull);
    AddKeyword("Eye", FuncEye);
    AddKeyword("Arange", FuncArange);
    AddKeyword("Linspace", FuncLinspace);
    AddKeyword("Reshape", FuncReshape);
    AddKeyword("Transpose", FuncTranspose);
    AddKeyword("Add", FuncAdd);
    AddKeyword("Sub", FuncSub);
    AddKeyword("Mul", FuncMul);
    AddKeyword("Div", FuncDiv);
    AddKeyword("Pow", FuncPow);
    AddKeyword("Clip", FuncClip);
    AddKeyword("Var", FuncVar);
    AddKeyword("Std", FuncStd);
    AddKeyword("ArgMin", FuncArgMin);
    AddKeyword("ArgMax", FuncArgMax);
    AddKeyword("CumSum", FuncCumSum);
    AddKeyword("ArgSort", FuncArgSort);
    AddKeyword("Dot", FuncDot);
    AddKeyword("Det", FuncDet);
    AddKeyword("Inv", FuncInv);
    AddKeyword("Solve", FuncSolve);
    AddKeyword("Trace", FuncTrace);
    AddKeyword("Norm", FuncNorm);

    help_dict->insert({ "help", "\tNumPPL.help([name]) - displays this help message." });
    help_dict->insert({ "Zeros", "\tNumPPL.Zeros(dim1)[(dim2)...](dst) - creates an array filled with 0." });
    help_dict->insert({ "Ones", "\tNumPPL.Ones(dim1)[(dim2)...](dst) - creates an array filled with 1." });
    help_dict->insert({ "Full", "\tNumPPL.Full(value)(dim1)[(dim2)...](dst) - creates an array filled with value." });
    help_dict->insert({ "Eye", "\tNumPPL.Eye(n)[(m)](dst) - identity matrix n x n (or n x m)." });
    help_dict->insert({ "Arange", "\tNumPPL.Arange(start)(stop)[(step)](dst) - values start, start+step, ... below stop." });
    help_dict->insert({ "Linspace", "\tNumPPL.Linspace(start)(stop)(num)(dst) - num evenly spaced values, both ends included." });
    help_dict->insert({ "Reshape", "\tNumPPL.Reshape(src)(dim1)[(dim2)...](dst) - new shape, same data (one dim may be -1)." });
    help_dict->insert({ "Transpose", "\tNumPPL.Transpose(src)(dst) - reverses the order of the axes." });
    help_dict->insert({ "Add", "\tNumPPL.Add(a)(b)(dst) - a + b, element-wise with broadcasting; a and b: storage or number." });
    help_dict->insert({ "Sub", "\tNumPPL.Sub(a)(b)(dst) - a - b, element-wise with broadcasting." });
    help_dict->insert({ "Mul", "\tNumPPL.Mul(a)(b)(dst) - a * b, element-wise with broadcasting." });
    help_dict->insert({ "Div", "\tNumPPL.Div(a)(b)(dst) - a / b, element-wise with broadcasting." });
    help_dict->insert({ "Pow", "\tNumPPL.Pow(a)(b)(dst) - a ^ b, element-wise with broadcasting." });
    help_dict->insert({ "Clip", "\tNumPPL.Clip(a)(lo)(hi)(dst) - limits every value to [lo, hi]." });
    help_dict->insert({ "Var", "\tNumPPL.Var(src)(target_var) - population variance of all values." });
    help_dict->insert({ "Std", "\tNumPPL.Std(src)(target_var) - population standard deviation of all values." });
    help_dict->insert({ "ArgMin", "\tNumPPL.ArgMin(src)(target_var) - flat index of the first minimum." });
    help_dict->insert({ "ArgMax", "\tNumPPL.ArgMax(src)(target_var) - flat index of the first maximum." });
    help_dict->insert({ "CumSum", "\tNumPPL.CumSum(src)(dst) - running sum over the flattened array, same shape." });
    help_dict->insert({ "ArgSort", "\tNumPPL.ArgSort(src)(dst) - flat indices that sort the values ascending (stable)." });
    help_dict->insert({ "Dot", "\tNumPPL.Dot(a)(b)(dst) - vector.vector -> variable; matrix.matrix, matrix.vector -> storage." });
    help_dict->insert({ "Det", "\tNumPPL.Det(a)(target_var) - determinant of a square matrix." });
    help_dict->insert({ "Inv", "\tNumPPL.Inv(a)(dst) - inverse of a square matrix." });
    help_dict->insert({ "Solve", "\tNumPPL.Solve(a)(b)(dst) - solves a x = b (b: vector or matrix)." });
    help_dict->insert({ "Trace", "\tNumPPL.Trace(a)(target_var) - sum of the main diagonal." });
    help_dict->insert({ "Norm", "\tNumPPL.Norm(a)(target_var) - Euclidean (Frobenius) norm of all values." });

    for (const auto& pair : *keyword_dict)
    {
      string key = "NumPPL." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "NumPPL", this });
  }

  //=======================================================
  // Argument handling (same logic as in StorageLib)
  //=======================================================
  static bool ExtractEvaluatedParamsForLibrary(Processing* proc, string func_name, const vector<string>& raw_params, Composite* node, NumArgs& out)
  {
    if (raw_params.empty())
    {
      return false;
    }

    string storage_name = raw_params[0];
    string evaluated_name;

    if (proc->GetValue(storage_name, evaluated_name) && !evaluated_name.empty())
    {
      storage_name = evaluated_name;
    }

    if (!storage_name.empty() && (storage_name.front() == '\"' || storage_name.front() == '\''))
    {
      char q = storage_name.front();
      storage_name.erase(0, 1);

      if (!storage_name.empty() && storage_name.back() == q)
      {
        storage_name.pop_back();
      }
    }

    out.eval.push_back(storage_name);
    out.raw.push_back(storage_name);

    int i = 1;
    while (i < static_cast<int>(raw_params.size()))
    {
      if (raw_params[i].empty())
      {
        i++;
        continue;
      }

      string raw_tmp = raw_params[i];
      if (!raw_tmp.empty() && (raw_tmp.front() == '\"' || raw_tmp.front() == '\''))
      {
        char q = raw_tmp.front();
        raw_tmp.erase(0, 1);

        if (!raw_tmp.empty() && raw_tmp.back() == q)
        {
          raw_tmp.pop_back();
        }
      }
      out.raw.push_back(raw_tmp);

      string tmp;
      int prev_i = i;
      bool success = proc->GetValueFromParameters(func_name, raw_params, i, tmp);

      if (!success)
      {
        tmp = "";
        if (!proc->GetValue(raw_params[i], tmp))
        {
          return false;
        }
        i++;
      }

      if (i == prev_i)
      {
        i++;
      }

      if (!tmp.empty() && (tmp.front() == '\"' || tmp.front() == '\''))
      {
        char quote = tmp.front();
        tmp.erase(0, 1);

        if (!tmp.empty() && tmp.back() == quote)
        {
          tmp.pop_back();
        }
      }
      out.eval.push_back(tmp);
    }

    return true;
  }

  // Strict, exception-free string -> double (the same rules as in StorageLib).
  static bool TryParseDouble(const string& str, double& out)
  {
    const char* b = str.data();
    const char* e = b + str.size();

    while (b < e && std::isspace(static_cast<unsigned char>(*b))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(e[-1]))) --e;

    if (b < e && *b == '+')
    {
      ++b;
      if (b < e && (*b == '-' || *b == '+')) return false; // "+-5", "++5"
    }
    if (b == e) return false;

    auto r = std::from_chars(b, e, out);
    return r.ec == std::errc() && r.ptr == e;
  }

  // Shortest text that reads back to the same double.
  static string FormatNumber(double v)
  {
    char buf[64];
    auto r = std::to_chars(buf, buf + sizeof(buf), v);
    return string(buf, r.ptr);
  }

  bool NumPPL::Fail(const string& func_name, const string& message)
  {
    printDlgt({ "Error: [{0}] {1}", func_name, message });
    return false;
  }

  // Extracts the arguments and checks their number.
  bool NumPPL::Begin(const string& func_name, const string& usage, const vector<string>& parameters, Composite* node,
    size_t min_args, NumArgs& args)
  {
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }
    if (args.eval.size() < min_args || args.raw.size() < min_args)
    {
      return Fail(func_name, "missing arguments. Format: " + usage);
    }
    return true;
  }

  StorageComponent* NumPPL::FindStorage(const string& name)
  {
    Component* c = ppl->processing->scopeManager.LookupVariable(name);
    StorageComponent* st = dynamic_cast<StorageComponent*>(c);
    if (!st && c && !c->value.empty())
    {
      st = dynamic_cast<StorageComponent*>(ppl->processing->scopeManager.LookupVariable(c->value));
    }
    return st;
  }

  StorageComponent* NumPPL::GetDstStorage(const string& func_name, const string& name)
  {
    StorageComponent* dst = FindStorage(name);
    if (!dst)
    {
      Fail(func_name, "target variable [" + name + "] not found or is not a storage.");
    }
    return dst;
  }

  Component* NumPPL::GetTarget(const string& func_name, const string& name)
  {
    Component* target = ppl->processing->scopeManager.LookupVariable(name);
    if (!target)
    {
      Fail(func_name, "target variable [" + name + "] not found.");
    }
    return target;
  }

  // Storage -> dense row-major array. The storage must be rectangular and numeric.
  std::expected<NumArr, string> NumPPL::ReadStorage(StorageComponent* st)
  {
    const int nd = st->GetDimensionsCount();
    if (nd < 1)
    {
      return std::unexpected("storage has no dimensions");
    }

    NumArr arr;
    vector<int> path;
    for (int d = 0; d < nd; ++d)
    {
      int n = st->GetDimSize(path);
      if (n <= 0)
      {
        return std::unexpected("storage is empty");
      }
      arr.shape.push_back(static_cast<size_t>(n));
      path.push_back(0);
    }

    size_t total = 1;
    for (size_t n : arr.shape) total *= n;
    arr.data.reserve(total);

    string error;
    path.clear();
    auto walk = [&](auto&& self, size_t dim) -> bool
      {
        if (dim == arr.shape.size())
        {
          string text;
          double v = 0.0;
          if (!st->GetItem(path, text) || !TryParseDouble(text, v))
          {
            error = "storage element is not a number: [" + text + "]";
            return false;
          }
          arr.data.push_back(v);
          return true;
        }
        if (static_cast<size_t>(st->GetDimSize(path)) != arr.shape[dim])
        {
          error = "storage is jagged (rows of different length)";
          return false;
        }
        for (size_t i = 0; i < arr.shape[dim]; ++i)
        {
          path.push_back(static_cast<int>(i));
          bool ok = self(self, dim + 1);
          path.pop_back();
          if (!ok) return false;
        }
        return true;
      };
    if (!walk(walk, 0))
    {
      return std::unexpected(error);
    }
    return arr;
  }

  // Argument i: an existing storage (array) or a number (rank 0).
  std::expected<NumArr, string> NumPPL::Operand(const NumArgs& args, size_t i)
  {
    if (i >= args.eval.size() || i >= args.raw.size())
    {
      return std::unexpected("missing argument");
    }
    if (StorageComponent* st = FindStorage(args.raw[i]))
    {
      auto r = ReadStorage(st);
      if (!r) return std::unexpected("[" + args.raw[i] + "]: " + r.error());
      return r;
    }
    double v = 0.0;
    if (!TryParseDouble(args.eval[i], v))
    {
      return std::unexpected("[" + args.raw[i] + "] is neither a storage nor a number");
    }
    return NumArr{ {}, { v } };
  }

  static void BuildNode(StorageNode& node, const NumArr& arr, size_t dim, size_t& pos)
  {
    node.is_leaf = false;
    node.children.resize(arr.shape[dim]);
    for (StorageNode& child : node.children)
    {
      if (dim + 1 == arr.shape.size())
      {
        child.is_leaf = true;
        child.value = FormatNumber(arr.data[pos++]);
      }
      else
      {
        BuildNode(child, arr, dim + 1, pos);
      }
    }
  }

  bool NumPPL::StoreArray(const string& func_name, const string& dst_name, const NumArr& arr)
  {
    StorageComponent* dst = GetDstStorage(func_name, dst_name);
    if (!dst)
    {
      return false;
    }
    if (arr.shape.empty())
    {
      return Fail(func_name, "the result is a single number, it cannot be stored in a storage");
    }
    StorageNode root;
    size_t pos = 0;
    BuildNode(root, arr, 0, pos);
    dst->SetRoot(std::move(root));
    return true;
  }

  bool NumPPL::StoreScalar(const string& func_name, const string& var_name, double v, string& result)
  {
    Component* target = GetTarget(func_name, var_name);
    if (!target)
    {
      return false;
    }
    result = target->value = FormatNumber(v);
    return true;
  }

  //=======================================================
  // Numeric helpers (no PPL types)
  //=======================================================
  static size_t CountOf(const vector<size_t>& shape)
  {
    return std::ranges::fold_left(shape, size_t{ 1 }, std::multiplies<>{});
  }

  // Row-major strides; a broadcast (size 1) axis gets stride 0.
  static vector<size_t> StridesFor(const vector<size_t>& shape, size_t rank)
  {
    vector<size_t> st(rank, 0);
    size_t step = 1;
    for (size_t k = 0; k < shape.size(); ++k)
    {
      size_t axis = shape.size() - 1 - k;
      st[rank - 1 - k] = shape[axis] == 1 ? 0 : step;
      step *= shape[axis];
    }
    return st;
  }

  static std::expected<NumArr, string> Broadcast(const NumArr& a, const NumArr& b, double (*op)(double, double))
  {
    const size_t rank = (std::max)(a.shape.size(), b.shape.size());
    if (rank == 0)
    {
      return std::unexpected("at least one operand must be a storage");
    }

    NumArr out;
    out.shape.assign(rank, 1);
    for (size_t k = 0; k < rank; ++k)
    {
      size_t da = k < a.shape.size() ? a.shape[a.shape.size() - 1 - k] : 1;
      size_t db = k < b.shape.size() ? b.shape[b.shape.size() - 1 - k] : 1;
      if (da != db && da != 1 && db != 1)
      {
        return std::unexpected("shapes cannot be broadcast together");
      }
      out.shape[rank - 1 - k] = da == 1 ? db : da;
    }

    const size_t total = CountOf(out.shape);
    out.data.resize(total);
    const vector<size_t> sa = StridesFor(a.shape, rank);
    const vector<size_t> sb = StridesFor(b.shape, rank);

    vector<size_t> idx(rank, 0);
    size_t oa = 0, ob = 0;
    for (size_t n = 0; n < total; ++n)
    {
      out.data[n] = op(a.data[oa], b.data[ob]);
      for (size_t k = rank; k-- > 0;)          // odometer increment
      {
        ++idx[k];
        oa += sa[k];
        ob += sb[k];
        if (idx[k] < out.shape[k]) break;
        oa -= sa[k] * idx[k];
        ob -= sb[k] * idx[k];
        idx[k] = 0;
      }
    }
    return out;
  }

  // Row-major 2-D view; C++23 multidimensional operator[].
  struct Mat2
  {
    double* p;
    size_t rows, cols;
    double& operator[](size_t i, size_t j) const { return p[i * cols + j]; }
  };

  // Gauss-Jordan with partial pivoting: solves A X = B in place (A: n x n, B: n x k).
  // A becomes garbage, B becomes X. Returns false if A is singular; det is the determinant (0 if singular).
  static bool GaussJordan(vector<double>& A, size_t n, vector<double>& B, size_t k, double& det)
  {
    Mat2 a{ A.data(), n, n };
    Mat2 b{ B.data(), n, k };

    double scale = 0.0;
    for (double v : A) scale = (std::max)(scale, std::fabs(v));
    const double tiny = scale * static_cast<double>(n) * std::numeric_limits<double>::epsilon();

    det = 1.0;
    for (size_t c = 0; c < n; ++c)
    {
      size_t piv = c;
      for (size_t r = c + 1; r < n; ++r)
      {
        if (std::fabs(a[r, c]) > std::fabs(a[piv, c])) piv = r;
      }
      if (!(std::fabs(a[piv, c]) > tiny))
      {
        det = 0.0;
        return false;
      }
      if (piv != c)
      {
        for (size_t j = 0; j < n; ++j) std::swap(a[piv, j], a[c, j]);
        for (size_t j = 0; j < k; ++j) std::swap(b[piv, j], b[c, j]);
        det = -det;
      }
      const double d = a[c, c];
      det *= d;
      for (size_t j = 0; j < n; ++j) a[c, j] /= d;
      for (size_t j = 0; j < k; ++j) b[c, j] /= d;
      for (size_t r = 0; r < n; ++r)
      {
        if (r == c) continue;
        const double f = a[r, c];
        if (f == 0.0) continue;
        for (size_t j = 0; j < n; ++j) a[r, j] -= f * a[c, j];
        for (size_t j = 0; j < k; ++j) b[r, j] -= f * b[c, j];
      }
    }
    return true;
  }

  //=======================================================
  // Creation:  dst is the last argument
  //=======================================================
  static bool ParseDims(const NumArgs& args, size_t from, size_t to, vector<size_t>& dims, string& err)
  {
    dims.clear();
    for (size_t i = from; i < to; ++i)
    {
      double v = 0.0;
      if (!TryParseDouble(args.eval[i], v) || v != std::floor(v) || v < 1.0 || v > 1.0e9)
      {
        err = "dimension [" + args.eval[i] + "] must be an integer >= 1";
        return false;
      }
      dims.push_back(static_cast<size_t>(v));
    }
    double total = 1.0;
    for (size_t d : dims) total *= static_cast<double>(d);
    if (total > 2.0e8)
    {
      err = "array is too large";
      return false;
    }
    return true;
  }

  static bool Filled(NumPPL* self, const string& fn, const string& usage, const vector<string>& parameters, Composite* node,
    bool with_value, double fixed, string& result)
  {
    (void)result;
    NumArgs args;
    const size_t head = with_value ? 1 : 0;
    if (!self->Begin(fn, usage, parameters, node, head + 2, args)) return false;

    double value = fixed;
    if (with_value && !TryParseDouble(args.eval[0], value))
    {
      return self->Fail(fn, "value [" + args.eval[0] + "] is not a number");
    }
    NumArr arr;
    string err;
    if (!ParseDims(args, head, args.eval.size() - 1, arr.shape, err))
    {
      return self->Fail(fn, err);
    }
    arr.data.assign(CountOf(arr.shape), value);
    return self->StoreArray(fn, args.raw.back(), arr);
  }

  bool NumPPL::FuncZeros(const vector<string>& parameters, string& result, Composite* node)
  {
    return Filled(this, "NumPPL.Zeros", "NumPPL.Zeros(dim1)[(dim2)...](dst)", parameters, node, false, 0.0, result);
  }

  bool NumPPL::FuncOnes(const vector<string>& parameters, string& result, Composite* node)
  {
    return Filled(this, "NumPPL.Ones", "NumPPL.Ones(dim1)[(dim2)...](dst)", parameters, node, false, 1.0, result);
  }

  bool NumPPL::FuncFull(const vector<string>& parameters, string& result, Composite* node)
  {
    return Filled(this, "NumPPL.Full", "NumPPL.Full(value)(dim1)[(dim2)...](dst)", parameters, node, true, 0.0, result);
  }

  bool NumPPL::FuncEye(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Eye";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Eye(n)[(m)](dst)", parameters, node, 2, args)) return false;
    if (args.eval.size() > 3) return Fail(fn, "too many arguments. Format: NumPPL.Eye(n)[(m)](dst)");

    NumArr arr;
    string err;
    if (!ParseDims(args, 0, args.eval.size() - 1, arr.shape, err)) return Fail(fn, err);
    const size_t n = arr.shape[0];
    const size_t m = arr.shape.size() > 1 ? arr.shape[1] : n;
    arr.shape = { n, m };
    arr.data.assign(n * m, 0.0);
    Mat2 view{ arr.data.data(), n, m };
    for (size_t i = 0; i < (std::min)(n, m); ++i) view[i, i] = 1.0;
    return StoreArray(fn, args.raw.back(), arr);
  }

  bool NumPPL::FuncArange(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Arange";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Arange(start)(stop)[(step)](dst)", parameters, node, 3, args)) return false;
    if (args.eval.size() > 4) return Fail(fn, "too many arguments");

    const size_t nums = args.eval.size() - 1;
    double v[3] = { 0.0, 0.0, 1.0 };
    for (size_t i = 0; i < nums; ++i)
    {
      if (!TryParseDouble(args.eval[i], v[i])) return Fail(fn, "[" + args.eval[i] + "] is not a number");
    }
    const double start = v[0], stop = v[1], step = v[2];
    if (step == 0.0 || !std::isfinite(start) || !std::isfinite(stop) || !std::isfinite(step))
    {
      return Fail(fn, "step must be a non-zero finite number");
    }
    const double count = std::ceil((stop - start) / step);
    if (!(count >= 1.0)) return Fail(fn, "the range is empty");
    if (count > 2.0e8) return Fail(fn, "array is too large");

    NumArr arr;
    arr.shape = { static_cast<size_t>(count) };
    for (size_t i : std::views::iota(size_t{ 0 }, arr.shape[0]))
    {
      arr.data.push_back(start + static_cast<double>(i) * step);
    }
    return StoreArray(fn, args.raw.back(), arr);
  }

  bool NumPPL::FuncLinspace(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Linspace";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Linspace(start)(stop)(num)(dst)", parameters, node, 4, args)) return false;

    double start = 0.0, stop = 0.0, num = 0.0;
    if (!TryParseDouble(args.eval[0], start) || !TryParseDouble(args.eval[1], stop) || !TryParseDouble(args.eval[2], num))
    {
      return Fail(fn, "start, stop and num must be numbers");
    }
    if (num != std::floor(num) || num < 1.0 || num > 2.0e8) return Fail(fn, "num must be an integer >= 1");

    NumArr arr;
    const size_t n = static_cast<size_t>(num);
    arr.shape = { n };
    arr.data.resize(n);
    for (size_t i = 0; i < n; ++i)
    {
      arr.data[i] = (n == 1) ? start : (i + 1 == n ? stop : start + (stop - start) * static_cast<double>(i) / static_cast<double>(n - 1));
    }
    return StoreArray(fn, args.raw.back(), arr);
  }

  //=======================================================
  // Shape
  //=======================================================
  bool NumPPL::FuncReshape(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Reshape";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Reshape(src)(dim1)[(dim2)...](dst)", parameters, node, 3, args)) return false;

    auto src = Operand(args, 0);
    if (!src) return Fail(fn, src.error());
    if (src->shape.empty()) return Fail(fn, "the source must be a storage");

    vector<long long> dims;
    long long unknown = -1;
    size_t known = 1;
    for (size_t i = 1; i + 1 < args.eval.size(); ++i)
    {
      double v = 0.0;
      if (!TryParseDouble(args.eval[i], v) || v != std::floor(v) || (v < 1.0 && v != -1.0) || v > 1.0e9)
      {
        return Fail(fn, "dimension [" + args.eval[i] + "] must be an integer >= 1 (or -1 once)");
      }
      if (v == -1.0)
      {
        if (unknown >= 0) return Fail(fn, "only one dimension may be -1");
        unknown = static_cast<long long>(dims.size());
      }
      else
      {
        known *= static_cast<size_t>(v);
      }
      dims.push_back(static_cast<long long>(v));
    }
    const size_t total = src->data.size();
    if (unknown >= 0)
    {
      if (total % known != 0) return Fail(fn, "cannot reshape " + to_string(total) + " values to this shape");
      dims[unknown] = static_cast<long long>(total / known);
    }
    else if (known != total)
    {
      return Fail(fn, "cannot reshape " + to_string(total) + " values to this shape");
    }

    NumArr out;
    for (long long d : dims) out.shape.push_back(static_cast<size_t>(d));
    out.data = std::move(src->data);
    return StoreArray(fn, args.raw.back(), out);
  }

  bool NumPPL::FuncTranspose(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Transpose";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Transpose(src)(dst)", parameters, node, 2, args)) return false;

    auto src = Operand(args, 0);
    if (!src) return Fail(fn, src.error());
    if (src->shape.empty()) return Fail(fn, "the source must be a storage");

    const size_t rank = src->shape.size();
    NumArr out;
    out.shape.assign(src->shape.rbegin(), src->shape.rend());
    out.data.resize(src->data.size());

    // source strides in row-major order, read in reversed axis order
    vector<size_t> sstride(rank, 1);
    for (size_t k = rank - 1; k-- > 0;) sstride[k] = sstride[k + 1] * src->shape[k + 1];

    vector<size_t> idx(rank, 0);
    size_t off = 0;
    for (size_t n = 0; n < out.data.size(); ++n)
    {
      out.data[n] = src->data[off];
      for (size_t k = rank; k-- > 0;)    // output axis k is source axis rank-1-k
      {
        const size_t s = sstride[rank - 1 - k];
        ++idx[k];
        off += s;
        if (idx[k] < out.shape[k]) break;
        off -= s * idx[k];
        idx[k] = 0;
      }
    }
    return StoreArray(fn, args.raw.back(), out);
  }

  //=======================================================
  // Element-wise with broadcasting
  //=======================================================
  bool NumPPL::Elementwise(const string& fn, const vector<string>& parameters, Composite* node, double (*op)(double, double))
  {
    NumArgs args;
    if (!Begin(fn, fn + "(a)(b)(dst)", parameters, node, 3, args)) return false;

    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    auto b = Operand(args, 1);
    if (!b) return Fail(fn, b.error());
    auto r = Broadcast(*a, *b, op);
    if (!r) return Fail(fn, r.error());
    return StoreArray(fn, args.raw.back(), *r);
  }

  bool NumPPL::FuncAdd(const vector<string>& parameters, string& result, Composite* node)
  {
    return Elementwise("NumPPL.Add", parameters, node, [](double a, double b) { return a + b; });
  }

  bool NumPPL::FuncSub(const vector<string>& parameters, string& result, Composite* node)
  {
    return Elementwise("NumPPL.Sub", parameters, node, [](double a, double b) { return a - b; });
  }

  bool NumPPL::FuncMul(const vector<string>& parameters, string& result, Composite* node)
  {
    return Elementwise("NumPPL.Mul", parameters, node, [](double a, double b) { return a * b; });
  }

  bool NumPPL::FuncDiv(const vector<string>& parameters, string& result, Composite* node)
  {
    return Elementwise("NumPPL.Div", parameters, node, [](double a, double b) { return a / b; });
  }

  bool NumPPL::FuncPow(const vector<string>& parameters, string& result, Composite* node)
  {
    return Elementwise("NumPPL.Pow", parameters, node, [](double a, double b) { return std::pow(a, b); });
  }

  bool NumPPL::FuncClip(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Clip";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Clip(a)(lo)(hi)(dst)", parameters, node, 4, args)) return false;

    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (a->shape.empty()) return Fail(fn, "the first argument must be a storage");
    double lo = 0.0, hi = 0.0;
    if (!TryParseDouble(args.eval[1], lo) || !TryParseDouble(args.eval[2], hi)) return Fail(fn, "lo and hi must be numbers");
    if (lo > hi) return Fail(fn, "lo must not be greater than hi");

    for (double& v : a->data)
    {
      if (!std::isnan(v)) v = std::clamp(v, lo, hi);
    }
    return StoreArray(fn, args.raw.back(), *a);
  }

  //=======================================================
  // Statistics over all values: the result goes to a variable
  //=======================================================
  bool NumPPL::Reduce(const string& fn, const vector<string>& parameters, Composite* node, string& result,
    double (*calc)(const vector<double>&))
  {
    NumArgs args;
    if (!Begin(fn, fn + "(src)(target_var)", parameters, node, 2, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (a->shape.empty()) return Fail(fn, "the source must be a storage");
    return StoreScalar(fn, args.raw.back(), calc(a->data), result);
  }

  static double Variance(const vector<double>& v)
  {
    const double n = static_cast<double>(v.size());
    const double mean = std::ranges::fold_left(v, 0.0, std::plus<>{}) / n;
    double s = 0.0;
    for (double x : v) s += (x - mean) * (x - mean);
    return s / n;
  }

  bool NumPPL::FuncVar(const vector<string>& parameters, string& result, Composite* node)
  {
    return Reduce("NumPPL.Var", parameters, node, result, Variance);
  }

  bool NumPPL::FuncStd(const vector<string>& parameters, string& result, Composite* node)
  {
    return Reduce("NumPPL.Std", parameters, node, result, [](const vector<double>& v) { return std::sqrt(Variance(v)); });
  }

  // NaN values are skipped; if every value is NaN the index is 0
  bool NumPPL::FuncArgMin(const vector<string>& parameters, string& result, Composite* node)
  {
    return Reduce("NumPPL.ArgMin", parameters, node, result, [](const vector<double>& v)
      {
        size_t best = 0;
        for (size_t i = 0; i < v.size(); ++i)
        {
          if (!std::isnan(v[i]) && (std::isnan(v[best]) || v[i] < v[best])) best = i;
        }
        return static_cast<double>(best);
      });
  }

  bool NumPPL::FuncArgMax(const vector<string>& parameters, string& result, Composite* node)
  {
    return Reduce("NumPPL.ArgMax", parameters, node, result, [](const vector<double>& v)
      {
        size_t best = 0;
        for (size_t i = 0; i < v.size(); ++i)
        {
          if (!std::isnan(v[i]) && (std::isnan(v[best]) || v[i] > v[best])) best = i;
        }
        return static_cast<double>(best);
      });
  }

  bool NumPPL::FuncNorm(const vector<string>& parameters, string& result, Composite* node)
  {
    return Reduce("NumPPL.Norm", parameters, node, result, [](const vector<double>& v)
      {
        double big = 0.0;
        for (double x : v) big = (std::max)(big, std::fabs(x));
        if (big == 0.0 || !std::isfinite(big)) return big;
        double s = 0.0;
        for (double x : v) s += (x / big) * (x / big);
        return big * std::sqrt(s);
      });
  }

  //=======================================================
  // Array results
  //=======================================================
  bool NumPPL::FuncCumSum(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.CumSum";
    NumArgs args;
    if (!Begin(fn, "NumPPL.CumSum(src)(dst)", parameters, node, 2, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (a->shape.empty()) return Fail(fn, "the source must be a storage");
    std::inclusive_scan(a->data.begin(), a->data.end(), a->data.begin());
    return StoreArray(fn, args.raw.back(), *a);
  }

  // stable ascending order, NaN last
  bool NumPPL::FuncArgSort(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.ArgSort";
    NumArgs args;
    if (!Begin(fn, "NumPPL.ArgSort(src)(dst)", parameters, node, 2, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (a->shape.empty()) return Fail(fn, "the source must be a storage");

    vector<size_t> order(a->data.size());
    std::iota(order.begin(), order.end(), size_t{ 0 });
    const vector<double>& d = a->data;
    std::ranges::stable_sort(order, [&d](size_t x, size_t y)
      {
        if (std::isnan(d[x])) return false;
        if (std::isnan(d[y])) return true;
        return d[x] < d[y];
      });

    NumArr out;
    out.shape = { order.size() };
    out.data.assign(order.begin(), order.end());
    return StoreArray(fn, args.raw.back(), out);
  }

  //=======================================================
  // Linear algebra
  //=======================================================
  static bool IsSquare(const NumArr& a)
  {
    return a.shape.size() == 2 && a.shape[0] == a.shape[1];
  }

  bool NumPPL::FuncDot(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Dot";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Dot(a)(b)(dst)", parameters, node, 3, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    auto b = Operand(args, 1);
    if (!b) return Fail(fn, b.error());

    const size_t ra = a->shape.size(), rb = b->shape.size();
    if (ra < 1 || ra > 2 || rb < 1 || rb > 2)
    {
      return Fail(fn, "both arguments must be storages with 1 or 2 dimensions");
    }
    const size_t inner_a = a->shape[ra - 1];
    const size_t inner_b = rb == 1 ? b->shape[0] : b->shape[0];
    if (inner_a != inner_b)
    {
      return Fail(fn, "shapes do not match: " + to_string(inner_a) + " vs " + to_string(inner_b));
    }

    if (ra == 1 && rb == 1)
    {
      double s = 0.0;
      for (size_t i = 0; i < inner_a; ++i) s += a->data[i] * b->data[i];
      return StoreScalar(fn, args.raw.back(), s, result);
    }

    const size_t rows = ra == 2 ? a->shape[0] : 1;
    const size_t cols = rb == 2 ? b->shape[1] : 1;
    NumArr out;
    if (ra == 2 && rb == 2) out.shape = { rows, cols };
    else if (ra == 2) out.shape = { rows };
    else out.shape = { cols };
    out.data.assign(rows * cols, 0.0);

    Mat2 ma{ a->data.data(), rows, inner_a };
    Mat2 mb{ b->data.data(), inner_a, cols };
    Mat2 mo{ out.data.data(), rows, cols };
    for (size_t i = 0; i < rows; ++i)
    {
      for (size_t k = 0; k < inner_a; ++k)
      {
        const double f = ma[i, k];
        for (size_t j = 0; j < cols; ++j) mo[i, j] += f * mb[k, j];
      }
    }
    return StoreArray(fn, args.raw.back(), out);
  }

  bool NumPPL::FuncDet(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Det";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Det(a)(target_var)", parameters, node, 2, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (!IsSquare(*a)) return Fail(fn, "the argument must be a square matrix");

    vector<double> empty_b;
    double det = 0.0;
    GaussJordan(a->data, a->shape[0], empty_b, 0, det);     // singular -> det = 0
    return StoreScalar(fn, args.raw.back(), det, result);
  }

  bool NumPPL::FuncTrace(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Trace";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Trace(a)(target_var)", parameters, node, 2, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (a->shape.size() != 2) return Fail(fn, "the argument must be a matrix");

    Mat2 m{ a->data.data(), a->shape[0], a->shape[1] };
    double s = 0.0;
    for (size_t i = 0; i < (std::min)(m.rows, m.cols); ++i) s += m[i, i];
    return StoreScalar(fn, args.raw.back(), s, result);
  }

  bool NumPPL::FuncInv(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Inv";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Inv(a)(dst)", parameters, node, 2, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    if (!IsSquare(*a)) return Fail(fn, "the argument must be a square matrix");

    const size_t n = a->shape[0];
    vector<double> inv(n * n, 0.0);
    Mat2 id{ inv.data(), n, n };
    for (size_t i = 0; i < n; ++i) id[i, i] = 1.0;

    double det = 0.0;
    if (!GaussJordan(a->data, n, inv, n, det)) return Fail(fn, "the matrix is singular");
    NumArr out;
    out.shape = { n, n };
    out.data = std::move(inv);
    return StoreArray(fn, args.raw.back(), out);
  }

  bool NumPPL::FuncSolve(const vector<string>& parameters, string& result, Composite* node)
  {
    string fn = "NumPPL.Solve";
    NumArgs args;
    if (!Begin(fn, "NumPPL.Solve(a)(b)(dst)", parameters, node, 3, args)) return false;
    auto a = Operand(args, 0);
    if (!a) return Fail(fn, a.error());
    auto b = Operand(args, 1);
    if (!b) return Fail(fn, b.error());
    if (!IsSquare(*a)) return Fail(fn, "a must be a square matrix");
    if (b->shape.empty() || b->shape.size() > 2 || b->shape[0] != a->shape[0])
    {
      return Fail(fn, "b must be a vector or a matrix with " + to_string(a->shape[0]) + " rows");
    }

    const size_t n = a->shape[0];
    const size_t k = b->shape.size() == 2 ? b->shape[1] : 1;
    double det = 0.0;
    if (!GaussJordan(a->data, n, b->data, k, det)) return Fail(fn, "the matrix is singular");
    return StoreArray(fn, args.raw.back(), *b);      // b now holds x, same shape as b
  }

}
