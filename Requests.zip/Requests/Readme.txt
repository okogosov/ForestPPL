git-scm.com/download/win
Скачайте 64-bit Git for Windows Setup

git --version
cd C:\
git clone https://github.com/microsoft/vcpkg.git

Сборка: нужна libcurl. 
На Windows vcpkg install curl:x64-windows и линковка libcurl.lib, 
	results:    C:\vcpkg\installed\x64-windows\
в WSL2 libcurl4-openssl-dev и -lcurl.

Linker → General → Additional Library Directories
libcurl-d.dll/libcurl.dll
zd.dll / z.dll


Linker → Input → Additional Dependencies:
libcurl-d.lib/libcurl.ib
 

Пуск → папка Visual Studio → x64 Native Tools Command Prompt for VS. Либо в самой VS: Tools → Command Line → Developer Command Prompt.
>dumpbin /dependents C:\Users\ok21\Projects\ForestPPL.v2005\x64\Debug\libcurl-d.dll



Запустите сервер в отдельном окне PowerShell:
   cd C:\Users\ok21\Projects\ForestPPL.v2005\examples\requests
   python requests_server.py 8099

Окно оставьте открытым.
3. Проверьте в браузере: http://127.0.0.1:8099/get должен вернуть JSON.
4. В интерпретаторе (из каталога, где лежит x64\Debug, как и раньше) выполните 
   по отдельности:

   rc examples\requests\requests_basic.scr
   rc examples\requests\requests_post.scr
   rc examples\requests\requests_auth_headers.scr
   rc examples\requests\requests_json.scr
   rc examples\requests\requests_files.scr
   rc examples\requests\requests_errors.scr


