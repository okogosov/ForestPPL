
#include "pch.h"
#include "curl/curl.h"
/*
#include <cstdio>
#include <cstring>
#include <cctype>
#include <fstream>
#include <algorithm>
*/
#include "..\PPL\PPL.h"
#include "..\PPL\Component\Component.h"
#include "..\PPL\Processing\processing.h"
#include "Requests.h"



using namespace std;
namespace PPLNS
{
  static Requests* REQUESTSInstance = nullptr;

  void Requests_CreateInstance(PPL* ppl)
  {
    curl_global_init(CURL_GLOBAL_DEFAULT);
    REQUESTSInstance = new Requests(ppl);
    REQUESTSInstance->AddToKeywordDictionary();
  }

  Requests::Requests(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }

  //=======================================================
  void Requests::AddToKeywordDictionary()
  {
    //help_dict is created in BaseClass
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Get", FuncGet);
    AddKeyword("Post", FuncPost);
    AddKeyword("PostJson", FuncPostJson);
    AddKeyword("Put", FuncPut);
    AddKeyword("Patch", FuncPatch);
    AddKeyword("Head", FuncHead);
    AddKeyword("Request", FuncRequest);
    AddKeyword("Status", FuncStatus);
    AddKeyword("Text", FuncText);
    AddKeyword("Header", FuncHeader);
    AddKeyword("Headers", FuncHeaders);
    AddKeyword("Ok", FuncOk);
    AddKeyword("Url", FuncUrl);
    AddKeyword("Elapsed", FuncElapsed);
    AddKeyword("Error", FuncError);
    AddKeyword("JsonGet", FuncJsonGet);
    AddKeyword("Save", FuncSave);
    AddKeyword("Download", FuncDownload);
    AddKeyword("SetTimeout", FuncSetTimeout);
    AddKeyword("SetHeader", FuncSetHeader);
    AddKeyword("ClearHeaders", FuncClearHeaders);
    AddKeyword("SetAuth", FuncSetAuth);
    AddKeyword("SetBearer", FuncSetBearer);
    AddKeyword("SetVerify", FuncSetVerify);
    AddKeyword("SetUserAgent", FuncSetUserAgent);
    AddKeyword("SetProxy", FuncSetProxy);
    AddKeyword("Write", FuncWrite);
    AddKeyword("Count", FuncCount);
    AddKeyword("Remove", FuncRemove);
    AddKeyword("Delete", FuncDelete);

    help_dict->insert({ "help",         "\tRequests.help([name])" });
    help_dict->insert({ "Get",          "\tHTTP GET, stores the response under response_name, returns the status code:\r\n\tRequests.Get(response_name)(url)" });
    help_dict->insert({ "Post",         "\tHTTP POST with form data (application/x-www-form-urlencoded), returns the status code:\r\n\tRequests.Post(response_name)(url)(\"key=value&key2=value2\")" });
    help_dict->insert({ "PostJson",     "\tHTTP POST with Content-Type: application/json, returns the status code:\r\n\tRequests.PostJson(response_name)(url)(json_string)" });
    help_dict->insert({ "Put",          "\tHTTP PUT, returns the status code: Requests.Put(response_name)(url)(data)" });
    help_dict->insert({ "Patch",        "\tHTTP PATCH, returns the status code: Requests.Patch(response_name)(url)(data)" });
    help_dict->insert({ "Head",         "\tHTTP HEAD (headers only), returns the status code: Requests.Head(response_name)(url)" });
    help_dict->insert({ "Request",      "\tAny HTTP method (DELETE, OPTIONS, ...), returns the status code:\r\n\tRequests.Request(response_name)(method)(url)[(data)]" });
    help_dict->insert({ "Status",       "\tReturns the HTTP status code of the response (0 if the request failed): Requests.Status(response_name)" });
    help_dict->insert({ "Text",         "\tReturns the response body: Requests.Text(response_name)" });
    help_dict->insert({ "Header",       "\tReturns the value of a response header (case-insensitive), nan if absent:\r\n\tRequests.Header(response_name)(header_name)" });
    help_dict->insert({ "Headers",      "\tReturns all response headers as text, one \"Name: value\" per line: Requests.Headers(response_name)" });
    help_dict->insert({ "Ok",           "\tReturns True if the request succeeded and status < 400, else False: Requests.Ok(response_name)" });
    help_dict->insert({ "Url",          "\tReturns the final URL after redirects: Requests.Url(response_name)" });
    help_dict->insert({ "Elapsed",      "\tReturns the request duration in milliseconds: Requests.Elapsed(response_name)" });
    help_dict->insert({ "Error",        "\tReturns the transport error text (timeout, DNS, TLS ...), empty string if none: Requests.Error(response_name)" });
    help_dict->insert({ "JsonGet",      "\tReturns a value from the JSON body by path, nan if absent. Path syntax: a.b[0].c\r\n\tRequests.JsonGet(response_name)(path)" });
    help_dict->insert({ "Save",         "\tWrites the response body to a file, returns True: Requests.Save(response_name)(filename)" });
    help_dict->insert({ "Download",     "\tDownloads url straight into a file, returns the status code: Requests.Download(url)(filename)" });
    help_dict->insert({ "SetTimeout",   "\tSets the timeout in seconds for the following requests (default 30, 0 = no timeout): Requests.SetTimeout(seconds)" });
    help_dict->insert({ "SetHeader",    "\tSets (or replaces) a header sent with every request: Requests.SetHeader(name)(value)" });
    help_dict->insert({ "ClearHeaders", "\tRemoves all headers set by SetHeader: Requests.ClearHeaders()" });
    help_dict->insert({ "SetAuth",      "\tHTTP Basic authentication; empty user disables it: Requests.SetAuth(user)(password)" });
    help_dict->insert({ "SetBearer",    "\tSends Authorization: Bearer <token>; empty token disables it: Requests.SetBearer(token)" });
    help_dict->insert({ "SetVerify",    "\tEnables or disables TLS certificate verification (default yes): Requests.SetVerify(yes|no)" });
    help_dict->insert({ "SetUserAgent", "\tSets the User-Agent header: Requests.SetUserAgent(text)" });
    help_dict->insert({ "SetProxy",     "\tSets a proxy, e.g. http://host:3128; empty string disables it: Requests.SetProxy(url)" });
    help_dict->insert({ "Write",        "\tWrites response names or details of response_name to the standard output stream:\r\n\tRequests.Write([response_name])" });
    help_dict->insert({ "Count",        "\tReturns the number of stored responses: Requests.Count()" });
    help_dict->insert({ "Remove",       "\tRemoves one stored response: Requests.Remove(response_name)" });
    help_dict->insert({ "Delete",       "\tDeletes all stored responses (settings are kept): Requests.Delete()" });

    for (const auto pair : *keyword_dict)
    {
      string key = "Requests." + pair.first;
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "Requests", this });
  }

  //=========================================================
  // small helpers
  //=========================================================
  static string Unquote(string s)
  {
    if (!s.empty() && s.front() == '\"')
    {
      s.erase(0, 1);
      if (!s.empty() && s.back() == '\"') s.pop_back();
    }
    return s;
  }

  static string ToLower(string s)
  {
    transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)tolower(c); });
    return s;
  }

  static string ToUpper(string s)
  {
    transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)toupper(c); });
    return s;
  }

  static string Trim(const string& s)
  {
    size_t b = 0, e = s.size();
    while (b < e && isspace((unsigned char)s[b])) b++;
    while (e > b && isspace((unsigned char)s[e - 1])) e--;
    return s.substr(b, e - b);
  }

  // Reads and unquotes all parameters, checks their number
  bool Requests::GetArgs(const string& func_name, const vector<string>& parameters,
                         size_t min_args, size_t max_args, vector<string>& args)
  {
    args.clear();
    if (parameters.size() < min_args || parameters.size() > max_args)
    {
      string expected = (min_args == max_args) ? to_string(min_args) : to_string(min_args) + ".." + to_string(max_args);
      printDlgt({ "Error: [{0}] wrong number of parameters != {1}", func_name, expected });
      return false;
    }
    string fname = func_name;      // GetValueFromParameters takes a non-const string&
    for (size_t i = 0; i < parameters.size(); i++)
    {
      int indexInParameters = (int)i;
      string value;
      if (!GetValueFromParameters(fname, parameters, indexInParameters, value)) return false;
      args.push_back(Unquote(value));
    }
    return true;
  }

  bool Requests::GetResponseByName(const string& func_name, const string& name, Response*& resp)
  {
    for (size_t j = 0; j < responses.size(); j++)
    {
      if (responses[j].name == name)
      {
        resp = &responses[j];
        return true;
      }
    }
    printDlgt({ "Error: [{0}] wrong name [{1}]", func_name, name });
    return false;
  }

  //=========================================================
  // libcurl glue
  //=========================================================
  static size_t CurlWriteString(char* ptr, size_t size, size_t nmemb, void* userdata)
  {
    static_cast<string*>(userdata)->append(ptr, size * nmemb);
    return size * nmemb;
  }

  static size_t CurlWriteFile(char* ptr, size_t size, size_t nmemb, void* userdata)
  {
    ofstream* f = static_cast<ofstream*>(userdata);
    f->write(ptr, (streamsize)(size * nmemb));
    return f->good() ? size * nmemb : 0;
  }

  static size_t CurlHeaderLine(char* buffer, size_t size, size_t nitems, void* userdata)
  {
    size_t total = size * nitems;
    auto* headers = static_cast<vector<std::pair<string, string>>*>(userdata);
    string line(buffer, total);

    if (line.compare(0, 5, "HTTP/") == 0)
    {
      headers->clear();          // new status line (redirect / 100-continue): keep only the last block
      return total;
    }
    size_t colon = line.find(':');
    if (colon != string::npos)
    {
      headers->push_back({ Trim(line.substr(0, colon)), Trim(line.substr(colon + 1)) });
    }
    return total;
  }

  static bool HasHeader(const vector<std::pair<string, string>>& h, const string& name)
  {
    string lname = ToLower(name);
    for (const auto& p : h)
      if (ToLower(p.first) == lname) return true;
    return false;
  }

  // Performs one request. out_file != nullptr -> body goes to the file instead of resp.body
  static void PerformCurl(const string& method, const string& url, const string* data, bool json,
                          long timeout_sec, const vector<std::pair<string, string>>& default_headers,
                          bool use_basic_auth, const string& auth_user, const string& auth_password,
                          const string& bearer_token, bool verify_ssl, const string& user_agent,
                          const string& proxy, ofstream* out_file, long& status, string& body,
                          vector<std::pair<string, string>>& resp_headers, string& eff_url,
                          double& elapsed_ms, string& error)
  {
    status = 0; error.clear();
    CURL* curl = curl_easy_init();
    if (!curl) { error = "curl_easy_init failed"; return; }

    char errbuf[CURL_ERROR_SIZE];
    errbuf[0] = '\0';

    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 10L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout_sec);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, timeout_sec);
    curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");           // accept and decode gzip/deflate
    curl_easy_setopt(curl, CURLOPT_USERAGENT, user_agent.c_str());
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, verify_ssl ? 1L : 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, verify_ssl ? 2L : 0L);
    if (!proxy.empty()) curl_easy_setopt(curl, CURLOPT_PROXY, proxy.c_str());
    if (use_basic_auth)
    {
      curl_easy_setopt(curl, CURLOPT_HTTPAUTH, (long)CURLAUTH_BASIC);
      curl_easy_setopt(curl, CURLOPT_USERNAME, auth_user.c_str());
      curl_easy_setopt(curl, CURLOPT_PASSWORD, auth_password.c_str());
    }

    if (out_file)
    {
      curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, CurlWriteFile);
      curl_easy_setopt(curl, CURLOPT_WRITEDATA, out_file);
    }
    else
    {
      curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, CurlWriteString);
      curl_easy_setopt(curl, CURLOPT_WRITEDATA, &body);
    }
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, CurlHeaderLine);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, &resp_headers);

    // method and body
    string m = ToUpper(method);
    if (m == "GET")
    {
      curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);
    }
    else if (m == "HEAD")
    {
      curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    }
    else
    {
      if (m != "POST") curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, m.c_str());
      static const string empty;
      const string& d = data ? *data : empty;
      curl_easy_setopt(curl, CURLOPT_POSTFIELDS, d.c_str());
      curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE_LARGE, (curl_off_t)d.size());
    }

    // headers
    struct curl_slist* slist = nullptr;
    for (const auto& h : default_headers)
      slist = curl_slist_append(slist, (h.first + ": " + h.second).c_str());
    if (json && !HasHeader(default_headers, "Content-Type"))
      slist = curl_slist_append(slist, "Content-Type: application/json");
    if (!bearer_token.empty() && !HasHeader(default_headers, "Authorization"))
      slist = curl_slist_append(slist, ("Authorization: Bearer " + bearer_token).c_str());
    if (slist) curl_easy_setopt(curl, CURLOPT_HTTPHEADER, slist);

    CURLcode rc = curl_easy_perform(curl);
    if (rc != CURLE_OK)
    {
      error = errbuf[0] ? string(errbuf) : string(curl_easy_strerror(rc));
    }
    else
    {
      curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    }
    char* eurl = nullptr;
    if (curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &eurl) == CURLE_OK && eurl) eff_url = eurl;
    double total = 0;
    if (curl_easy_getinfo(curl, CURLINFO_TOTAL_TIME, &total) == CURLE_OK) elapsed_ms = total * 1000.0;

    if (slist) curl_slist_free_all(slist);
    curl_easy_cleanup(curl);
  }

  // Performs a request and stores the response under resp_name; result = status code
  bool Requests::DoRequest(const string& func_name, const string& resp_name, const string& method,
                           const string& url, const string* data, bool json, string& result)
  {
    if (resp_name.empty())
    {
      printDlgt({ "Error: [{0}] empty response name", func_name });
      return false;
    }
    if (url.empty())
    {
      printDlgt({ "Error: [{0}] empty url", func_name });
      return false;
    }

    Response r;
    r.name = resp_name;
    PerformCurl(method, url, data, json, timeout_sec, default_headers, use_basic_auth, auth_user,
                auth_password, bearer_token, verify_ssl, user_agent, proxy, nullptr, r.status, r.body,
                r.headers, r.url, r.elapsed_ms, r.error);

    bool replaced = false;
    for (auto& existing : responses)
    {
      if (existing.name == resp_name) { existing = r; replaced = true; break; }
    }
    if (!replaced) responses.push_back(r);

    result = to_string(r.status);
    return true;
  }

  //=========================================================
  // requests
  //=========================================================
  //Requests.Get(response_name)(url)
  bool Requests::FuncGet(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncGet";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    return DoRequest(func_name, a[0], "GET", a[1], nullptr, false, result);
  }

  //Requests.Post(response_name)(url)(data)
  bool Requests::FuncPost(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncPost";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 3, 3, a)) return false;
    return DoRequest(func_name, a[0], "POST", a[1], &a[2], false, result);
  }

  //Requests.PostJson(response_name)(url)(json)
  bool Requests::FuncPostJson(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncPostJson";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 3, 3, a)) return false;
    return DoRequest(func_name, a[0], "POST", a[1], &a[2], true, result);
  }

  //Requests.Put(response_name)(url)(data)
  bool Requests::FuncPut(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncPut";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 3, 3, a)) return false;
    return DoRequest(func_name, a[0], "PUT", a[1], &a[2], false, result);
  }

  //Requests.Patch(response_name)(url)(data)
  bool Requests::FuncPatch(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncPatch";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 3, 3, a)) return false;
    return DoRequest(func_name, a[0], "PATCH", a[1], &a[2], false, result);
  }

  //Requests.Head(response_name)(url)
  bool Requests::FuncHead(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncHead";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    return DoRequest(func_name, a[0], "HEAD", a[1], nullptr, false, result);
  }

  //Requests.Request(response_name)(method)(url)[(data)]
  bool Requests::FuncRequest(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncRequest";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 3, 4, a)) return false;

    string method = ToUpper(a[1]);
    bool valid = !method.empty();
    for (unsigned char c : method) if (!isalpha(c)) valid = false;
    if (!valid)
    {
      printDlgt({ "Error: [{0}] wrong method [{1}]", func_name, a[1] });
      return false;
    }
    const string* data = (a.size() == 4) ? &a[3] : nullptr;
    return DoRequest(func_name, a[0], method, a[2], data, false, result);
  }

  //=========================================================
  // response accessors
  //=========================================================
  //Requests.Status(response_name)
  bool Requests::FuncStatus(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncStatus";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;
    result = to_string(r->status);
    return true;
  }

  //Requests.Text(response_name)
  bool Requests::FuncText(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncText";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;
    result = r->body;
    return true;
  }

  //Requests.Header(response_name)(header_name)
  bool Requests::FuncHeader(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncHeader";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;

    string wanted = ToLower(a[1]);
    bool found = false;
    result.clear();
    for (const auto& h : r->headers)
    {
      if (ToLower(h.first) == wanted)
      {
        if (found) result += ", ";
        result += h.second;
        found = true;
      }
    }
    if (!found) result = "nan";
    return true;
  }

  //Requests.Headers(response_name)
  bool Requests::FuncHeaders(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncHeaders";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;

    result.clear();
    for (size_t i = 0; i < r->headers.size(); i++)
    {
      if (i) result += "\n";
      result += r->headers[i].first + ": " + r->headers[i].second;
    }
    return true;
  }

  //Requests.Ok(response_name)
  bool Requests::FuncOk(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncOk";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;
    result = (r->error.empty() && r->status > 0 && r->status < 400) ? "True" : "False";
    return true;
  }

  //Requests.Url(response_name)
  bool Requests::FuncUrl(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncUrl";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;
    result = r->url;
    return true;
  }

  //Requests.Elapsed(response_name)
  bool Requests::FuncElapsed(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncElapsed";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;
    char buf[64];
    snprintf(buf, sizeof(buf), "%.3f", r->elapsed_ms);
    result = buf;
    return true;
  }

  //Requests.Error(response_name)
  bool Requests::FuncError(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncError";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;
    result = r->error;
    return true;
  }

  //=========================================================
  // JSON path lookup (minimal reader, no external packages)
  //=========================================================
  static void JsonSkipWs(const string& s, size_t& i)
  {
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++;
  }

  static bool JsonHex4(const string& s, size_t& i, unsigned& cp)
  {
    if (i + 4 > s.size()) return false;
    cp = 0;
    for (int k = 0; k < 4; k++)
    {
      char c = s[i + k];
      cp <<= 4;
      if (c >= '0' && c <= '9') cp |= (unsigned)(c - '0');
      else if (c >= 'a' && c <= 'f') cp |= (unsigned)(c - 'a' + 10);
      else if (c >= 'A' && c <= 'F') cp |= (unsigned)(c - 'A' + 10);
      else return false;
    }
    i += 4;
    return true;
  }

  static void JsonAppendUtf8(string& out, unsigned cp)
  {
    if (cp < 0x80) out += (char)cp;
    else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
    else { out += (char)(0xF0 | (cp >> 18)); out += (char)(0x80 | ((cp >> 12) & 0x3F)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
  }

  // s[i] == '"'; decodes the string, leaves i after the closing quote
  static bool JsonParseString(const string& s, size_t& i, string& out)
  {
    if (i >= s.size() || s[i] != '"') return false;
    i++;
    out.clear();
    while (i < s.size())
    {
      char c = s[i++];
      if (c == '"') return true;
      if (c != '\\') { out += c; continue; }
      if (i >= s.size()) return false;
      char e = s[i++];
      switch (e)
      {
      case '"':  out += '"';  break;
      case '\\': out += '\\'; break;
      case '/':  out += '/';  break;
      case 'b':  out += '\b'; break;
      case 'f':  out += '\f'; break;
      case 'n':  out += '\n'; break;
      case 'r':  out += '\r'; break;
      case 't':  out += '\t'; break;
      case 'u':
      {
        unsigned cp;
        if (!JsonHex4(s, i, cp)) return false;
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 1 < s.size() && s[i] == '\\' && s[i + 1] == 'u')
        {
          size_t j = i + 2;
          unsigned lo;
          if (JsonHex4(s, j, lo) && lo >= 0xDC00 && lo <= 0xDFFF)
          {
            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
            i = j;
          }
        }
        JsonAppendUtf8(out, cp);
        break;
      }
      default: return false;
      }
    }
    return false;
  }

  // Skips one value starting at s[i] (after optional whitespace)
  static bool JsonSkipValue(const string& s, size_t& i)
  {
    JsonSkipWs(s, i);
    if (i >= s.size()) return false;
    char c = s[i];
    if (c == '"') { string dummy; return JsonParseString(s, i, dummy); }
    if (c == '{' || c == '[')
    {
      int depth = 0;
      while (i < s.size())
      {
        char ch = s[i];
        if (ch == '"') { string dummy; if (!JsonParseString(s, i, dummy)) return false; continue; }
        if (ch == '{' || ch == '[') depth++;
        else if (ch == '}' || ch == ']') { depth--; if (depth == 0) { i++; return true; } }
        i++;
      }
      return false;
    }
    size_t b = i;
    while (i < s.size() && string(",]} \t\r\n").find(s[i]) == string::npos) i++;
    return i > b;
  }

  // Finds the child of the value that starts at s[start]: by key (object) or by index (array)
  static bool JsonChild(const string& s, size_t start, bool by_key, const string& key, long index,
                        size_t& vs, size_t& ve)
  {
    size_t i = start;
    JsonSkipWs(s, i);
    if (i >= s.size()) return false;

    if (by_key)
    {
      if (s[i] != '{') return false;
      i++;
      for (;;)
      {
        JsonSkipWs(s, i);
        if (i >= s.size() || s[i] == '}') return false;
        string k;
        if (!JsonParseString(s, i, k)) return false;
        JsonSkipWs(s, i);
        if (i >= s.size() || s[i] != ':') return false;
        i++;
        JsonSkipWs(s, i);
        size_t b = i;
        if (!JsonSkipValue(s, i)) return false;
        if (k == key) { vs = b; ve = i; return true; }
        JsonSkipWs(s, i);
        if (i < s.size() && s[i] == ',') i++;
      }
    }
    else
    {
      if (s[i] != '[') return false;
      i++;
      long n = 0;
      for (;;)
      {
        JsonSkipWs(s, i);
        if (i >= s.size() || s[i] == ']') return false;
        size_t b = i;
        if (!JsonSkipValue(s, i)) return false;
        if (n == index) { vs = b; ve = i; return true; }
        n++;
        JsonSkipWs(s, i);
        if (i < s.size() && s[i] == ',') i++;
      }
    }
  }

  // path := token { "." key | "[" number "]" }
  static bool JsonLookup(const string& json, const string& path, string& out)
  {
    size_t vs = 0, ve = 0;
    size_t i = 0;
    JsonSkipWs(json, i);
    vs = i;
    if (!JsonSkipValue(json, i)) return false;
    ve = i;

    size_t p = 0;
    while (p < path.size())
    {
      size_t cs = 0, ce = 0;
      if (path[p] == '.')
      {
        p++;
        continue;
      }
      if (path[p] == '[')
      {
        size_t close = path.find(']', p);
        if (close == string::npos) return false;
        string num = path.substr(p + 1, close - p - 1);
        if (num.empty() || num.find_first_not_of("0123456789") != string::npos) return false;
        long idx = atol(num.c_str());
        if (!JsonChild(json, vs, false, "", idx, cs, ce)) return false;
        p = close + 1;
      }
      else
      {
        size_t q = path.find_first_of(".[", p);
        if (q == string::npos) q = path.size();
        string key = path.substr(p, q - p);
        if (!JsonChild(json, vs, true, key, 0, cs, ce)) return false;
        p = q;
      }
      vs = cs;
      ve = ce;
    }

    if (json[vs] == '"')
    {
      size_t k = vs;
      return JsonParseString(json, k, out);
    }
    out = json.substr(vs, ve - vs);
    return true;
  }

  //Requests.JsonGet(response_name)(path)
  bool Requests::FuncJsonGet(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncJsonGet";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;

    if (!JsonLookup(r->body, a[1], result)) result = "nan";
    return true;
  }

  //=========================================================
  // files
  //=========================================================
  //Requests.Save(response_name)(filename)
  bool Requests::FuncSave(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSave";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;

    ofstream f(a[1], ios::binary | ios::trunc);
    if (!f.is_open())
    {
      printDlgt({ "Error: [{0}] cannot open file [{1}]", func_name, a[1] });
      return false;
    }
    f.write(r->body.data(), (streamsize)r->body.size());
    f.close();
    result = "True";
    return true;
  }

  //Requests.Download(url)(filename)
  bool Requests::FuncDownload(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncDownload";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;

    ofstream f(a[1], ios::binary | ios::trunc);
    if (!f.is_open())
    {
      printDlgt({ "Error: [{0}] cannot open file [{1}]", func_name, a[1] });
      return false;
    }

    long status = 0;
    string body, eff_url, error;
    vector<std::pair<string, string>> hdrs;
    double elapsed = 0;
    PerformCurl("GET", a[0], nullptr, false, timeout_sec, default_headers, use_basic_auth, auth_user,
                auth_password, bearer_token, verify_ssl, user_agent, proxy, &f, status, body, hdrs,
                eff_url, elapsed, error);
    f.close();

    if (!error.empty())
    {
      printDlgt({ "Error: [{0}] {1}", func_name, error });
      return false;
    }
    result = to_string(status);
    return true;
  }

  //=========================================================
  // session settings
  //=========================================================
  //Requests.SetTimeout(seconds)
  bool Requests::FuncSetTimeout(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetTimeout";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;

    string v = Trim(a[0]);
    if (v.empty() || v.find_first_not_of("0123456789") != string::npos)
    {
      printDlgt({ "Error: [{0}] timeout must be a non-negative integer, got [{1}]", func_name, a[0] });
      return false;
    }
    timeout_sec = atol(v.c_str());
    return true;
  }

  //Requests.SetHeader(name)(value)
  bool Requests::FuncSetHeader(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetHeader";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    if (a[0].empty() || a[0].find(':') != string::npos)
    {
      printDlgt({ "Error: [{0}] wrong header name [{1}]", func_name, a[0] });
      return false;
    }

    string lname = ToLower(a[0]);
    for (auto& h : default_headers)
    {
      if (ToLower(h.first) == lname) { h.second = a[1]; return true; }
    }
    default_headers.push_back({ a[0], a[1] });
    return true;
  }

  //Requests.ClearHeaders()
  bool Requests::FuncClearHeaders(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncClearHeaders";
    if (!parameters.empty())
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 0", func_name });
      return false;
    }
    default_headers.clear();
    return true;
  }

  //Requests.SetAuth(user)(password)
  bool Requests::FuncSetAuth(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetAuth";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 2, 2, a)) return false;
    use_basic_auth = !a[0].empty();
    auth_user = a[0];
    auth_password = a[1];
    if (use_basic_auth) bearer_token.clear();
    return true;
  }

  //Requests.SetBearer(token)
  bool Requests::FuncSetBearer(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetBearer";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    bearer_token = a[0];
    if (!bearer_token.empty()) { use_basic_auth = false; auth_user.clear(); auth_password.clear(); }
    return true;
  }

  //Requests.SetVerify(yes|no)
  bool Requests::FuncSetVerify(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetVerify";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;

    string v = ToLower(Trim(a[0]));
    if (v == "yes" || v == "true" || v == "1") verify_ssl = true;
    else if (v == "no" || v == "false" || v == "0") verify_ssl = false;
    else
    {
      printDlgt({ "Error: [{0}] expected yes|no, got [{1}]", func_name, a[0] });
      return false;
    }
    return true;
  }

  //Requests.SetUserAgent(text)
  bool Requests::FuncSetUserAgent(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetUserAgent";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    user_agent = a[0];
    return true;
  }

  //Requests.SetProxy(url)
  bool Requests::FuncSetProxy(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncSetProxy";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;
    proxy = a[0];
    return true;
  }

  //=========================================================
  // storage of responses
  //=========================================================
  //Requests.Write() or Requests.Write(response_name)
  bool Requests::FuncWrite(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncWrite";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 0, 1, a)) return false;

    if (a.empty())
    {
      if (responses.empty())
      {
        printDlgt({ "Warning: [Requests.FuncWrite] table of responses is empty" });
        return true;
      }
      for (const auto& r : responses)
      {
        printDlgt({ "{0}", r.name });
      }
      return true;
    }

    Response* r = nullptr;
    if (!GetResponseByName(func_name, a[0], r)) return false;

    printDlgt({ "==={0}===", r->name });
    printDlgt({ "\tstatus  : {0}", to_string(r->status) });
    printDlgt({ "\turl     : {0}", r->url });
    if (!r->error.empty()) printDlgt({ "\terror   : {0}", r->error });
    for (const auto& h : r->headers)
    {
      printDlgt({ "\theader  : {0}: {1}", h.first, h.second });
    }
    printDlgt({ "\tbody    : {0}", r->body });
    return true;
  }

  //Requests.Count()
  bool Requests::FuncCount(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncCount";
    if (!parameters.empty())
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 0", func_name });
      return false;
    }
    result = to_string(responses.size());
    return true;
  }

  //Requests.Remove(response_name)
  bool Requests::FuncRemove(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncRemove";
    vector<string> a;
    if (!GetArgs(func_name, parameters, 1, 1, a)) return false;

    for (size_t j = 0; j < responses.size(); j++)
    {
      if (responses[j].name == a[0])
      {
        responses.erase(responses.begin() + j);
        return true;
      }
    }
    printDlgt({ "Error: [{0}] wrong name [{1}]", func_name, a[0] });
    return false;
  }

  //Requests.Delete()
  bool Requests::FuncDelete(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "Requests.FuncDelete";
    if (!parameters.empty())
    {
      printDlgt({ "Error: [{0}] wrong number of parameters != 0", func_name });
      return false;
    }
    responses.clear();
    return true;
  }
}
