// change stod & sort to use string comparison for non-numeric values in FuncSort, and handle exceptions gracefully.
#include "pch.h"
#include "../PPL/PPL.h"
#include "../PPL/Component/Component.h"
#include "../PPL/Processing/Processing.h"
#include "StorageLib.h"
#include <unordered_set>
#include <random>
#include <algorithm>
#include <fstream>
#include <limits>
#include <functional>
#include <charconv>
#include <cmath>
#include <cctype>

using namespace std;

namespace PPLNS
{
  static StorageLib* STORAGELIBInstance = nullptr;

  // Scripts written on Windows often use '\\' in file paths
  // ("examples\\StorageLib\\file.csv"). Linux only understands '/', while
  // Windows accepts both, so converting on non-Windows systems is safe and
  // lets the same scripts run on both platforms.
  static string NormalizePath(string path)
  {
#ifndef _WIN32
    std::replace(path.begin(), path.end(), '\\', '/');
#endif
    return path;
  }

  static bool ExtractEvaluatedParamsForLibrary(Processing* proc, string func_name, const vector<string>& raw_params, Composite* node, ExtractedArgs& out)
  {
    if (raw_params.empty())
    {
      return false;
    }

    string storage_name = raw_params[0];
    string evaluated_name;

    if (proc->GetValue(storage_name, evaluated_name) && !evaluated_name.empty())
    {
      storage_name = evaluated_name;
    }

    if (!storage_name.empty() && (storage_name.front() == '\"' || storage_name.front() == '\''))
    {
      char q = storage_name.front();
      storage_name.erase(0, 1);

      if (!storage_name.empty() && storage_name.back() == q)
      {
        storage_name.pop_back();
      }
    }

    out.eval.push_back(storage_name);
    out.raw.push_back(storage_name);

    int i = 1;
    while (i < raw_params.size())
    {
      if (raw_params[i].empty())
      {
        i++;
        continue;
      }

      string raw_tmp = raw_params[i];
      if (!raw_tmp.empty() && (raw_tmp.front() == '\"' || raw_tmp.front() == '\''))
      {
        char q = raw_tmp.front();
        raw_tmp.erase(0, 1);

        if (!raw_tmp.empty() && raw_tmp.back() == q)
        {
          raw_tmp.pop_back();
        }
      }
      out.raw.push_back(raw_tmp);

      string tmp;
      int prev_i = i;
      bool success = proc->GetValueFromParameters(func_name, raw_params, i, tmp);

      if (!success)
      {
        tmp = "";
        if (!proc->GetValue(raw_params[i], tmp))
        {
          return false;
        }
        i++;
      }

      if (i == prev_i)
      {
        i++;
      }

      if (!tmp.empty() && (tmp.front() == '\"' || tmp.front() == '\''))
      {
        char quote = tmp.front();
        tmp.erase(0, 1);

        if (!tmp.empty() && tmp.back() == quote)
        {
          tmp.pop_back();
        }
      }
      out.eval.push_back(tmp);
    }

    return true;
  }

  // ===========================================================================
  // N-dimensional helpers
  // ===========================================================================

  // true if the node holds values (last dimension). An empty node counts as a row.
  static bool IsRowLevel(const StorageNode& n)
  {
    return n.children.empty() || n.children[0].is_leaf;
  }

  static void CollectLeaves(const StorageNode& n, vector<const StorageNode*>& out)
  {
    for (const auto& c : n.children)
    {
      if (c.is_leaf)
      {
        out.push_back(&c);
      }
      else
      {
        CollectLeaves(c, out);
      }
    }
  }

  // indices are eval[1 .. size - tail)
  static vector<string> IdxSlice(const ExtractedArgs& a, size_t tail)
  {
    vector<string> r;
    for (size_t i = 1; i + tail < a.eval.size(); ++i)
    {
      r.push_back(a.eval[i]);
    }
    return r;
  }

  // BEGIN NUMPARSE
  // Strict, exception-free string -> double. The whole string (ignoring
  // surrounding whitespace) must be a number; "12abc" is NOT a number.
  static bool TryParseDouble(const string& str, double& out)
  {
    const char* b = str.data();
    const char* e = b + str.size();

    while (b < e && std::isspace(static_cast<unsigned char>(*b))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(e[-1]))) --e;

    if (b < e && *b == '+')
    {
      ++b;
      if (b < e && (*b == '-' || *b == '+')) return false; // "+-5", "++5"
    }
    if (b == e) return false;

    auto r = std::from_chars(b, e, out);
    return r.ec == std::errc() && r.ptr == e;
  }

  // Sorts leaves numerically when EVERY value is a number, otherwise as plain
  // strings. Each value is parsed once (not O(n log n) times), and the
  // ordering is always a valid strict weak ordering (the old per-comparison
  // try/catch mixed numeric and string comparison, which is not).
  static void SortLeaves(vector<StorageNode>& items)
  {
    const size_t n = items.size();
    if (n < 2) return;

    vector<double> keys(n);
    bool all_numeric = true;

    for (size_t i = 0; i < n; ++i)
    {
      if (!TryParseDouble(items[i].value, keys[i]) || std::isnan(keys[i]))
      {
        all_numeric = false;
        break;
      }
    }

    if (!all_numeric)
    {
      std::stable_sort(items.begin(), items.end(), [](const StorageNode& a, const StorageNode& b)
        {
          return a.value < b.value;
        });
      return;
    }

    vector<size_t> order(n);
    for (size_t i = 0; i < n; ++i) order[i] = i;

    std::stable_sort(order.begin(), order.end(), [&keys](size_t a, size_t b)
      {
        return keys[a] < keys[b];
      });

    vector<StorageNode> sorted;
    sorted.reserve(n);
    for (size_t i : order) sorted.push_back(std::move(items[i]));
    items = std::move(sorted);
  }

  // Removes later duplicates (by exact string value), keeping first
  // occurrences in their original order. O(n), one pass; the old loop erased
  // from the middle of a vector one element at a time (O(n^2)).
  static void UniqueLeaves(vector<StorageNode>& items)
  {
    std::unordered_set<string> seen;
    seen.reserve(items.size());

    size_t w = 0;
    for (size_t r = 0; r < items.size(); ++r)
    {
      if (seen.insert(items[r].value).second)
      {
        if (w != r) items[w] = std::move(items[r]);
        ++w;
      }
    }
    items.resize(w);
  }
  // END NUMPARSE

  static string FormatNumber(double v)
  {
    string s = to_string(v);
    s.erase(s.find_last_not_of('0') + 1, std::string::npos);
    if (!s.empty() && s.back() == '.')
    {
      s.pop_back();
    }
    return s;
  }

  void StorageLib_CreateInstance(PPL* ppl)
  {
    STORAGELIBInstance = new StorageLib(ppl);
    STORAGELIBInstance->AddToKeywordDictionary();
  }

  StorageLib::StorageLib(PPL* ppl)
  {
    this->ppl = ppl;
    keyword_dict = new unordered_map<string, function<bool(const vector<string>&, string&, Composite*)>>;
  }

  void StorageLib::AddToKeywordDictionary()
  {
    AddKeyword("help", BaseClass::FuncHelp);
    AddKeyword("Push", FuncPush);
    AddKeyword("PushRow", FuncPushRow);
    AddKeyword("Pop", FuncPop);
    AddKeyword("Reverse", FuncReverse);
    AddKeyword("Shift", FuncShift);
    AddKeyword("Remove", FuncRemove);
    AddKeyword("Clear", FuncClear);
    AddKeyword("Unshift", FuncUnshift);
    AddKeyword("Insert", FuncInsert);
    AddKeyword("Slice", FuncSlice);
    AddKeyword("Sum", FuncSum);
    AddKeyword("Copy", FuncCopy);
    AddKeyword("Filtercopy", FuncFiltercopy);
    AddKeyword("Min", FuncMin);
    AddKeyword("Max", FuncMax);
    AddKeyword("Average", FuncAverage);
    AddKeyword("First", FuncFirst);
    AddKeyword("Last", FuncLast);
    AddKeyword("Concat", FuncConcat);
    AddKeyword("Sort", FuncSort);
    AddKeyword("Save", FuncSave);
    AddKeyword("ReadFile", FuncReadFile);
    AddKeyword("IndexOf", FuncIndexOf);
    AddKeyword("Contains", FuncContains);
    AddKeyword("CountOf", FuncCountOf);
    AddKeyword("Join", FuncJoin);
    AddKeyword("Split", FuncSplit);
    AddKeyword("Unique", FuncUnique);
    AddKeyword("Shuffle", FuncShuffle);
    AddKeyword("Product", FuncProduct);
    AddKeyword("Median", FuncMedian);

    help_dict->insert({ "help", "\tstorage.help([name]) - displays this help message." });
    help_dict->insert({ "Push", "\tstorage.Push(storage_name)[(index)...](value) - adds an element to the end of the last dimension." });
    help_dict->insert({ "PushRow", "\tstorage.PushRow(storage_name)[(index)...] - adds a zero-filled sub-array (clone of the last one) at the given level." });
    help_dict->insert({ "Pop", "\tstorage.Pop(storage_name)[(index)...](target_var) - removes and returns the last element." });
    help_dict->insert({ "Reverse", "\tstorage.Reverse(storage_name)[(index)...] - reverses the order of elements." });
    help_dict->insert({ "Shift", "\tstorage.Shift(storage_name)[(index)...](target_var) - removes and returns the first element." });
    help_dict->insert({ "Remove", "\tstorage.Remove(storage_name)[(index)...](position) - removes the element (or sub-array) at position." });
    help_dict->insert({ "Clear", "\tstorage.Clear(storage_name)[(index)...] - removes all elements." });
    help_dict->insert({ "Unshift", "\tstorage.Unshift(storage_name)[(index)...](value) - adds an element to the beginning." });
    help_dict->insert({ "Insert", "\tstorage.Insert(storage_name)[(index)...](position)(value) - inserts an element at position." });
    help_dict->insert({ "Slice", "\tstorage.Slice(storage_name)[(index)...](start)(end)(target_storage) - extracts a section." });
    help_dict->insert({ "Sum", "\tstorage.Sum(storage_name)[(index)...](target_var) - calculates the sum of all values." });
    help_dict->insert({ "Copy", "\tstorage.Copy(source)[(index)...](destination) - copies the (sub)array." });
    help_dict->insert({ "Filtercopy", "\tstorage.Filtercopy(source)[(index)...](dest) - copies non-zero values into a flat storage." });
    help_dict->insert({ "Min", "\tstorage.Min(storage_name)[(index)...](target_var) - finds minimum." });
    help_dict->insert({ "Max", "\tstorage.Max(storage_name)[(index)...](target_var) - finds maximum." });
    help_dict->insert({ "Average", "\tstorage.Average(storage_name)[(index)...](target_var) - calculates average." });
    help_dict->insert({ "First", "\tstorage.First(storage_name)[(index)...](target_var) - gets first element." });
    help_dict->insert({ "Last", "\tstorage.Last(storage_name)[(index)...](target_var) - gets last element." });
    help_dict->insert({ "Concat", "\tstorage.Concat(storage1)(storage2)(target) - concatenates arrays (sources may be \"s[1]\")." });
    help_dict->insert({ "Sort", "\tstorage.Sort(storage_name)[(index)...] - sorts elements in ascending order." });
    help_dict->insert({ "Save", "\tstorage.Save(storage_name)(filename.csv)[(delimiter)] - saves array." });
    help_dict->insert({ "ReadFile", "\tstorage.ReadFile(storage_name)(filename.csv)[(delimiter)] - loads array." });
    help_dict->insert({ "IndexOf", "\tstorage.IndexOf(storage_name)[(index)...](value)(target_var) - finds index." });
    help_dict->insert({ "Contains", "\tstorage.Contains(storage_name)[(index)...](value)(target_var) - returns True/False." });
    help_dict->insert({ "CountOf", "\tstorage.CountOf(storage_name)[(index)...](value)(target_var) - counts occurrences." });
    help_dict->insert({ "Join", "\tstorage.Join(storage_name)[(index)...](delimiter)(target_var) - joins into string." });
    help_dict->insert({ "Split", "\tstorage.Split(source_string)(delimiter)(target_storage) - splits string." });
    help_dict->insert({ "Unique", "\tstorage.Unique(storage_name)[(index)...] - removes duplicates." });
    help_dict->insert({ "Shuffle", "\tstorage.Shuffle(storage_name)[(index)...] - randomizes order." });
    help_dict->insert({ "Product", "\tstorage.Product(storage_name)[(index)...](target_var) - multiplies elements." });
    help_dict->insert({ "Median", "\tstorage.Median(storage_name)[(index)...](target_var) - calculates median." });

    for (const auto& pair : *keyword_dict)
    {
      string key = "storage." + pair.first;     // storage.Push instead of StorageLib.Push
      ppl->processing->keyword_dict->insert({ key, pair.second });
    }
    ppl->ImportList.insert({ "storage", this });
  }

  // ===========================================================================
  // Member helpers
  // ===========================================================================

  // spec: "s" or "s[1][2]" (indices may be variables); extra: already evaluated indices
  bool StorageLib::ResolveNode(const string& spec, const vector<string>& extra, StorageRef& ref, string& err)
  {
    size_t br = spec.find('[');
    string name = (br == string::npos) ? spec : spec.substr(0, br);

    vector<string> idx;
    for (size_t pos = br; pos != string::npos && pos < spec.size(); )
    {
      size_t close = spec.find(']', pos);
      if (spec[pos] != '[' || close == string::npos)
      {
        err = "wrong index syntax in [" + spec + "]";
        return false;
      }
      string expr = spec.substr(pos + 1, close - pos - 1);
      string val;
      if (ppl->processing->GetValue(expr, val) && !val.empty())
      {
        expr = val;
      }
      idx.push_back(expr);
      pos = close + 1;
    }
    idx.insert(idx.end(), extra.begin(), extra.end());

    ref.storage = dynamic_cast<StorageComponent*>(ppl->processing->scopeManager.LookupVariable(name));
    if (!ref.storage)
    {
      err = "storage [" + name + "] not found.";
      return false;
    }

    ref.node = &ref.storage->root;
    ref.path.clear();

    for (const string& expr : idx)
    {
      int i = 0;
      try
      {
        i = std::stoi(expr);
      }
      catch (...)
      {
        err = "invalid index [" + expr + "]";
        return false;
      }

      if (ref.node->is_leaf || i < 0 || i >= (int)ref.node->children.size())
      {
        err = "index [" + expr + "] out of bounds.";
        return false;
      }
      ref.node = &ref.node->children[i];
      ref.path.push_back(i);
    }

    if (ref.node->is_leaf)
    {
      err = "target is an element, not a sub-array.";
      return false;
    }
    return true;
  }

  bool StorageLib::Prepare(const string& func_name, const string& usage, const ExtractedArgs& args, size_t tail, StorageRef& ref)
  {
    if (args.eval.size() < 1 + tail)
    {
      printDlgt({ "Error: [{0}] missing arguments. {1}", func_name, usage });
      return false;
    }
    string err;
    if (!ResolveNode(args.eval[0], IdxSlice(args, tail), ref, err))
    {
      printDlgt({ "Error: [{0}] {1}", func_name, err });
      return false;
    }
    return true;
  }

  Component* StorageLib::GetTarget(const string& func_name, const string& name)
  {
    Component* target = ppl->processing->scopeManager.LookupVariable(name);
    if (!target)
    {
      printDlgt({ "Error: [{0}] target variable [{1}] not found.", func_name, name });
    }
    return target;
  }

  StorageComponent* StorageLib::GetDstStorage(const string& func_name, const string& name)
  {
    Component* var_dst = ppl->processing->scopeManager.LookupVariable(name);
    StorageComponent* dst = dynamic_cast<StorageComponent*>(var_dst);

    if (!dst && var_dst)
    {
      var_dst = ppl->processing->scopeManager.LookupVariable(var_dst->value);
      dst = dynamic_cast<StorageComponent*>(var_dst);
    }
    if (!dst)
    {
      printDlgt({ "Error: [{0}] target variable [{1}] not found or is not a storage.", func_name, name });
    }
    return dst;
  }

  bool StorageLib::NumericStat(const string& func_name, const vector<string>& parameters, string& result, Composite* node,
    const function<double(vector<double>&)>& calc)
  {
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: " + func_name + "(storage_name)[(index)...](target_var)", args, 1, ref))
    {
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    vector<const StorageNode*> leaves;
    CollectLeaves(*ref.node, leaves);

    vector<double> vals;
    vals.reserve(leaves.size());
    for (const auto* leaf : leaves)
    {
      double d;
      if (TryParseDouble(leaf->value, d))
      {
        vals.push_back(d);
      }
    }

    result = target_var->value = FormatNumber(vals.empty() ? 0.0 : calc(vals));
    return true;
  }

  // ===========================================================================
  // Add / remove
  // ===========================================================================

  bool StorageLib::FuncPush(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Push";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Push(storage_name)[(index)...](value)", args, 1, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension or use storage.PushRow", func_name });
      return false;
    }

    StorageNode new_node;
    ref.storage->InitNode(new_node, args.eval.back());
    ref.node->children.push_back(new_node);
    return true;
  }

  bool StorageLib::FuncPushRow(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.PushRow";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.PushRow(storage_name)[(index)...]", args, 0, ref))
    {
      return false;
    }

    if (IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target is the last dimension, use storage.Push", func_name });
      return false;
    }

    // ResizeDimension clones the shape of the last child and fills it with zeros
    if (!ref.storage->ResizeDimension(ref.path, (int)ref.node->children.size() + 1))
    {
      printDlgt({ "Error: [{0}] unable to add sub-array", func_name });
      return false;
    }
    return true;
  }

  bool StorageLib::FuncUnshift(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Unshift";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Unshift(storage_name)[(index)...](value)", args, 1, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }

    StorageNode new_node;
    ref.storage->InitNode(new_node, args.eval.back());
    ref.node->children.insert(ref.node->children.begin(), new_node);
    return true;
  }

  bool StorageLib::FuncInsert(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Insert";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Insert(storage_name)[(index)...](position)(value)", args, 2, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }

    int pos = 0;
    try
    {
      pos = std::stoi(args.eval[args.eval.size() - 2]);
    }
    catch (...)
    {
      printDlgt({ "Error: [{0}] invalid position parameter.", func_name });
      return false;
    }
    if (pos < 0 || pos >(int)ref.node->children.size())
    {
      printDlgt({ "Error: [{0}] position out of bounds.", func_name });
      return false;
    }

    StorageNode new_node;
    ref.storage->InitNode(new_node, args.eval.back());
    ref.node->children.insert(ref.node->children.begin() + pos, new_node);
    return true;
  }

  // removes an element (value level) or a whole sub-array (upper levels)
  bool StorageLib::FuncRemove(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Remove";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Remove(storage_name)[(index)...](position)", args, 1, ref))
    {
      return false;
    }

    int pos = 0;
    try
    {
      pos = std::stoi(args.eval.back());
    }
    catch (...)
    {
      printDlgt({ "Error: [{0}] invalid position parameter.", func_name });
      return false;
    }
    if (pos < 0 || pos >= (int)ref.node->children.size())
    {
      printDlgt({ "Error: [{0}] position out of bounds.", func_name });
      return false;
    }

    ref.node->children.erase(ref.node->children.begin() + pos);
    return true;
  }

  bool StorageLib::FuncPop(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Pop";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Pop(storage_name)[(index)...](target_var)", args, 1, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }
    if (ref.node->children.empty())
    {
      printDlgt({ "Error: [{0}] storage [{1}] is empty.", func_name, args.eval[0] });
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    result = target_var->value = ref.node->children.back().value;
    ref.node->children.pop_back();
    return true;
  }

  bool StorageLib::FuncShift(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Shift";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Shift(storage_name)[(index)...](target_var)", args, 1, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }
    if (ref.node->children.empty())
    {
      printDlgt({ "Error: [{0}] storage [{1}] is empty.", func_name, args.eval[0] });
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    result = target_var->value = ref.node->children.front().value;
    ref.node->children.erase(ref.node->children.begin());
    return true;
  }

  bool StorageLib::FuncFirst(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.First";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.First(storage_name)[(index)...](target_var)", args, 1, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }
    if (ref.node->children.empty())
    {
      printDlgt({ "Error: [{0}] storage [{1}] is empty.", func_name, args.eval[0] });
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    result = target_var->value = ref.node->children.front().value;
    return true;
  }

  bool StorageLib::FuncLast(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Last";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Last(storage_name)[(index)...](target_var)", args, 1, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }
    if (ref.node->children.empty())
    {
      printDlgt({ "Error: [{0}] storage [{1}] is empty.", func_name, args.eval[0] });
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    result = target_var->value = ref.node->children.back().value;
    return true;
  }

  // ===========================================================================
  // Clear, Reverse, Shuffle, Sort, Unique
  // ===========================================================================

  bool StorageLib::FuncClear(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Clear";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Clear(storage_name)[(index)...]", args, 0, ref))
    {
      return false;
    }

    ref.node->children.clear();
    return true;
  }

  bool StorageLib::FuncReverse(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Reverse";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Reverse(storage_name)[(index)...]", args, 0, ref))
    {
      return false;
    }

    std::reverse(ref.node->children.begin(), ref.node->children.end());
    return true;
  }

  bool StorageLib::FuncShuffle(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Shuffle";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Shuffle(storage_name)[(index)...]", args, 0, ref))
    {
      return false;
    }

    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(ref.node->children.begin(), ref.node->children.end(), g);
    return true;
  }

  bool StorageLib::FuncSort(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Sort";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Sort(storage_name)[(index)...]", args, 0, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }

    SortLeaves(ref.node->children);

    return true;
  }

  bool StorageLib::FuncUnique(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Unique";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Unique(storage_name)[(index)...]", args, 0, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }

    UniqueLeaves(ref.node->children);

    return true;
  }

  // ===========================================================================
  // Statistics over all leaves of the sub-tree
  // ===========================================================================

  bool StorageLib::FuncSum(const vector<string>& parameters, string& result, Composite* node)
  {
    return NumericStat("storage.Sum", parameters, result, node, [](vector<double>& v) -> double
      {
        double s = 0.0;
        for (double x : v) s += x;
        return s;
      });
  }

  bool StorageLib::FuncMin(const vector<string>& parameters, string& result, Composite* node)
  {
    return NumericStat("storage.Min", parameters, result, node, [](vector<double>& v) -> double
      {
        return *std::min_element(v.begin(), v.end());
      });
  }

  bool StorageLib::FuncMax(const vector<string>& parameters, string& result, Composite* node)
  {
    return NumericStat("storage.Max", parameters, result, node, [](vector<double>& v) -> double
      {
        return *std::max_element(v.begin(), v.end());
      });
  }

  bool StorageLib::FuncAverage(const vector<string>& parameters, string& result, Composite* node)
  {
    return NumericStat("storage.Average", parameters, result, node, [](vector<double>& v) -> double
      {
        double s = 0.0;
        for (double x : v) s += x;
        return s / static_cast<double>(v.size());
      });
  }

  bool StorageLib::FuncProduct(const vector<string>& parameters, string& result, Composite* node)
  {
    return NumericStat("storage.Product", parameters, result, node, [](vector<double>& v) -> double
      {
        double p = 1.0;
        for (double x : v) p *= x;
        return p;
      });
  }

  bool StorageLib::FuncMedian(const vector<string>& parameters, string& result, Composite* node)
  {
    return NumericStat("storage.Median", parameters, result, node, [](vector<double>& v) -> double
      {
        std::sort(v.begin(), v.end());
        size_t n = v.size();
        return (n % 2 == 0) ? (v[n / 2 - 1] + v[n / 2]) / 2.0 : v[n / 2];
      });
  }

  // ===========================================================================
  // Search and Join
  // ===========================================================================

  bool StorageLib::FuncIndexOf(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.IndexOf";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.IndexOf(storage_name)[(index)...](value)(target_var)", args, 2, ref))
    {
      return false;
    }

    if (!IsRowLevel(*ref.node))
    {
      printDlgt({ "Error: [{0}] target holds sub-arrays: add indices down to the last dimension", func_name });
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    const string& value = args.eval[args.eval.size() - 2];
    int found_idx = -1;
    for (size_t i = 0; i < ref.node->children.size(); i++)
    {
      if (ref.node->children[i].value == value)
      {
        found_idx = static_cast<int>(i);
        break;
      }
    }

    result = target_var->value = to_string(found_idx);
    return true;
  }

  // Contains and CountOf search all leaves of the sub-tree
  bool StorageLib::FuncContains(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Contains";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Contains(storage_name)[(index)...](value)(target_var)", args, 2, ref))
    {
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    vector<const StorageNode*> leaves;
    CollectLeaves(*ref.node, leaves);

    const string& value = args.eval[args.eval.size() - 2];
    bool found = false;
    for (const auto* leaf : leaves)
    {
      if (leaf->value == value)
      {
        found = true;
        break;
      }
    }

    result = target_var->value = found ? "True" : "False";
    return true;
  }

  bool StorageLib::FuncCountOf(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.CountOf";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.CountOf(storage_name)[(index)...](value)(target_var)", args, 2, ref))
    {
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    vector<const StorageNode*> leaves;
    CollectLeaves(*ref.node, leaves);

    const string& value = args.eval[args.eval.size() - 2];
    int count = 0;
    for (const auto* leaf : leaves)
    {
      if (leaf->value == value)
      {
        count++;
      }
    }

    result = target_var->value = to_string(count);
    return true;
  }

  bool StorageLib::FuncJoin(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Join";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef ref;
    if (!Prepare(func_name, "Format: storage.Join(storage_name)[(index)...](delimiter)(target_var)", args, 2, ref))
    {
      return false;
    }

    Component* target_var = GetTarget(func_name, args.raw.back());
    if (!target_var)
    {
      return false;
    }

    vector<const StorageNode*> leaves;
    CollectLeaves(*ref.node, leaves);

    const string& delim = args.eval[args.eval.size() - 2];
    string res;
    for (size_t i = 0; i < leaves.size(); i++)
    {
      res += leaves[i]->value;
      if (i != leaves.size() - 1)
      {
        res += delim;
      }
    }

    result = target_var->value = res;
    return true;
  }

  // ===========================================================================
  // Copy, Filtercopy, Slice, Concat (deep copies of sub-trees)
  // ===========================================================================

  bool StorageLib::FuncCopy(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Copy";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef src;
    if (!Prepare(func_name, "Format: storage.Copy(source)[(index)...](destination)", args, 1, src))
    {
      return false;
    }

    StorageComponent* dst = GetDstStorage(func_name, args.raw.back());
    if (!dst)
    {
      return false;
    }

    StorageNode tmp = *src.node;     // copy first: source and destination may be the same storage
    dst->root = std::move(tmp);
    dst->root.is_leaf = false;
    dst->dimensions_count = dst->GetDimensionsCount();
    return true;
  }

  // copies only non-zero values into a flat (1D) destination
  bool StorageLib::FuncFiltercopy(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Filtercopy";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef src;
    if (!Prepare(func_name, "Format: storage.Filtercopy(source)[(index)...](dest)", args, 1, src))
    {
      return false;
    }

    StorageComponent* dst = GetDstStorage(func_name, args.raw.back());
    if (!dst)
    {
      return false;
    }

    vector<const StorageNode*> leaves;
    CollectLeaves(*src.node, leaves);

    vector<StorageNode> kept;
    for (const auto* leaf : leaves)
    {
      if (leaf->value.empty() || leaf->value == "0" || leaf->value == "0.0")
      {
        continue;
      }
      StorageNode n;
      dst->InitNode(n, leaf->value);
      kept.push_back(n);
    }

    dst->root.is_leaf = false;
    dst->root.children = std::move(kept);
    dst->dimensions_count = 1;
    return true;
  }

  bool StorageLib::FuncSlice(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Slice";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    StorageRef src;
    if (!Prepare(func_name, "Format: storage.Slice(storage_name)[(index)...](start)(end)(target_storage)", args, 3, src))
    {
      return false;
    }

    StorageComponent* dst = GetDstStorage(func_name, args.raw.back());
    if (!dst)
    {
      return false;
    }

    int start_idx = 0;
    int end_idx = 0;
    try
    {
      start_idx = std::stoi(args.eval[args.eval.size() - 3]);
      end_idx = std::stoi(args.eval[args.eval.size() - 2]);
    }
    catch (...)
    {
      printDlgt({ "Error: [{0}] invalid start or end index.", func_name });
      return false;
    }

    int src_size = static_cast<int>(src.node->children.size());
    if (start_idx < 0)
    {
      start_idx = 0;
    }
    if (end_idx > src_size)
    {
      end_idx = src_size;
    }

    vector<StorageNode> part;
    for (int i = start_idx; i < end_idx; i++)
    {
      part.push_back(src.node->children[i]);     // deep copy
    }

    dst->root.is_leaf = false;
    dst->root.children = std::move(part);
    dst->dimensions_count = dst->GetDimensionsCount();
    return true;
  }

  // Concat(s1)(s2)(dest): sources may be given as "s[1]". Both must be on the same level.
  bool StorageLib::FuncConcat(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Concat";
    ExtractedArgs args;
    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    if (args.eval.size() < 3)
    {
      printDlgt({ "Error: [{0}] missing arguments. Format: storage.Concat(storage1)(storage2)(target)", func_name });
      return false;
    }

    StorageRef a;
    StorageRef b;
    string err;
    vector<string> no_idx;

    // a storage variable evaluates to an empty string: fall back to the raw name
    string src1 = args.eval[0].empty() ? args.raw[0] : args.eval[0];
    string src2 = args.eval[1].empty() ? args.raw[1] : args.eval[1];

    if (!ResolveNode(src1, no_idx, a, err))
    {
      printDlgt({ "Error: [{0}] source 1: {1}", func_name, err });
      return false;
    }
    if (!ResolveNode(src2, no_idx, b, err))
    {
      printDlgt({ "Error: [{0}] source 2: {1} (eval=[{2}] raw=[{3}] argc={4})", func_name, err, args.eval[1], args.raw[1], to_string(args.eval.size()) });
      return false;
    }

    if (IsRowLevel(*a.node) != IsRowLevel(*b.node))
    {
      printDlgt({ "Error: [{0}] sources are on different levels", func_name });
      return false;
    }

    StorageComponent* dst = GetDstStorage(func_name, args.raw[2]);
    if (!dst)
    {
      return false;
    }

    vector<StorageNode> merged = a.node->children;
    merged.insert(merged.end(), b.node->children.begin(), b.node->children.end());

    dst->root.is_leaf = false;
    dst->root.children = std::move(merged);
    dst->dimensions_count = dst->GetDimensionsCount();
    return true;
  }

  // ===========================================================================
  // Split (string -> storage), unchanged
  // ===========================================================================

  bool StorageLib::FuncSplit(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Split";
    ExtractedArgs args;

    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
    {
      return false;
    }

    if (args.eval.size() < 3)
    {
      printDlgt({ "Error: [{0}] missing arguments. Format: storage.Split(source_string)(delimiter)(target_storage)", func_name });
      return false;
    }

    string src_str = args.eval[0];
    string delim = args.eval[1];

    Component* var_dst = ppl->processing->scopeManager.LookupVariable(args.raw[2]);
    StorageComponent* dst_storage = dynamic_cast<StorageComponent*>(var_dst);

    if (!dst_storage && var_dst)
    {
      var_dst = ppl->processing->scopeManager.LookupVariable(var_dst->value);
      dst_storage = dynamic_cast<StorageComponent*>(var_dst);
    }

    if (!dst_storage)
    {
      printDlgt({ "Error: [{0}] target variable [{1}] not found or is not a storage.", func_name, args.raw[2] });
      return false;
    }

    dst_storage->root.children.clear();

    if (delim.empty())
    {
      StorageNode new_node;
      dst_storage->InitNode(new_node, src_str);
      dst_storage->root.children.push_back(new_node);
    }
    else
    {
      size_t pos = 0;
      while ((pos = src_str.find(delim)) != std::string::npos)
      {
        StorageNode new_node;
        dst_storage->InitNode(new_node, src_str.substr(0, pos));
        dst_storage->root.children.push_back(new_node);
        src_str.erase(0, pos + delim.length());
      }
      StorageNode new_node;
      dst_storage->InitNode(new_node, src_str);
      dst_storage->root.children.push_back(new_node);
    }

    return true;
  }

  //=============================================================================== 
  bool StorageLib::FuncSave(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.Save";
    ExtractedArgs args;

    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
      return false;

    if (args.eval.size() < 2)
    {
      printDlgt({ "Error: [{0}] missing arguments. Format: storage.Save(storage_name)(filename.csv)[(delimiter)]", func_name });
      return false;
    }

    string storage_name = args.eval[0];
    string filename = NormalizePath(args.eval[1]);
    string delimiter = "\n";
    bool is_newline_default = true;

    if (args.eval.size() > 2)
    {
      delimiter = args.eval[2];
      is_newline_default = false;
    }

    string extension = "";
    if (filename.ends_with(".csv")) extension = "csv";
    else if (filename.ends_with(".data")) extension = "data";

    if (extension.empty())
    {
      printDlgt({ "Error: [{0}] invalid file extension.", func_name });
      return false;
    }

    Component* var_comp = ppl->processing->scopeManager.LookupVariable(storage_name);
    StorageComponent* storage = dynamic_cast<StorageComponent*>(var_comp);

    if (!storage)
    {
      printDlgt({ "Error: [{0}] storage [{1}] not found.", func_name, args.eval[0] });
      return false;
    }

    if (extension == "csv")
    {
      string output = "";
      int dim_count = storage->GetDimensionsCount();

      // HEADER
      output += "_shape_";
      for (int i = 0; i < dim_count; i++) {
        output += "," + to_string(storage->GetDimSize(i));
      }
      string row_delimiter = (delimiter == "\n") ? "\n\n" : "\n";
      output += row_delimiter;

      // DATA
      size_t size = storage->root.children.size();
      if (size > 0)
      {
        if (dim_count == 1)
        {
          for (size_t i = 0; i < size; i++) {
            output += storage->root.children[i].value;
            if (i != size - 1) output += delimiter;
            else if (is_newline_default) output += "\n";
          }
        }
        else if (dim_count == 2)
        {
          for (size_t i = 0; i < size; i++) {
            const auto& row_node = storage->root.children[i];
            for (size_t j = 0; j < row_node.children.size(); j++) {
              output += row_node.children[j].value;
              if (j != row_node.children.size() - 1) output += delimiter;
            }
            if (i != size - 1) output += row_delimiter;
            else if (is_newline_default) output += "\n";
          }
        }
        else // 3D and higher (with empty separator columns)
        {
          for (size_t i = 0; i < size; i++)
          {
            const auto& row_node = storage->root.children[i];
            for (size_t j = 0; j < row_node.children.size(); j++)
            {
              vector<string> block_leaves;
              std::function<void(const StorageNode&)> Collect = [&](const StorageNode& n) {
                if (n.is_leaf) block_leaves.push_back(n.value);
                else for (const auto& c : n.children) Collect(c);
                };
              Collect(row_node.children[j]);

              for (size_t k = 0; k < block_leaves.size(); k++) {
                output += block_leaves[k];
                if (k != block_leaves.size() - 1) output += delimiter;
              }

              // double delimiter (creates an empty column in CSV)
              if (j != row_node.children.size() - 1 && !delimiter.empty()) {
                output += string(1, delimiter[0]) + string(1, delimiter[0]);
              }
            }
            if (i != size - 1) output += row_delimiter;
            else if (is_newline_default) output += "\n";
          }
        }
      }

      std::ofstream file(filename);
      if (!file.is_open())
      {
        printDlgt({ "Error: [{0}] unable to create file [{1}]", func_name, filename });
        return false;
      }
      file << output;
      file.close();
    }
    else
    {
      printDlgt({ "Error: [{0}] extension of file [{1}] not .csv", func_name, filename });
      return false;
    }

    return true;
  }

  //===============================================================================
  bool StorageLib::FuncReadFile(const vector<string>& parameters, string& result, Composite* node)
  {
    string func_name = "storage.ReadFile";
    ExtractedArgs args;

    if (!ExtractEvaluatedParamsForLibrary(ppl->processing, func_name, parameters, node, args))
      return false;

    if (args.eval.size() < 2)
    {
      printDlgt({ "Error: [{0}] missing arguments.", func_name });
      return false;
    }

    string storage_name = args.eval[0];
    string filename = NormalizePath(args.eval[1]);

    string delimiter_str = ",";
    if (args.eval.size() > 2 && !args.eval[2].empty())
    {
      delimiter_str = args.eval[2];
      if (delimiter_str == "\\n") delimiter_str = "\n";
    }
    char delimiter = delimiter_str[0];

    string extension = "";
    if (filename.ends_with(".csv")) extension = "csv";

    if (extension.empty())
    {
      printDlgt({ "Error: [{0}] file [{1}] must have .csv extension", func_name, filename });
      return false;
    }

    Component* var_comp = ppl->processing->scopeManager.LookupVariable(storage_name);
    StorageComponent* storage = dynamic_cast<StorageComponent*>(var_comp);
    if (!storage)
    {
      printDlgt({ "Error: [{0}] storage [{1}] not found.", func_name, storage_name });
      return false;
    }

    if (extension == "csv")
    {
      std::ifstream file(filename);
      if (!file.is_open())
      {
        printDlgt({ "Error: [{0}] unable to open file [{1}]", func_name, filename });
        return false;
      }

      vector<vector<string>> parsed_rows;
      vector<string> current_row;
      string line;
      bool first_line = true;
      vector<int> shape;

      while (getline(file, line))
      {
        if (!line.empty() && line.back() == '\r') line.pop_back();

        if (first_line && line.find("_shape_") == 0)
        {
          vector<string> shape_cells = ppl->processing->SplitCsv(line, ',');
          for (size_t i = 1; i < shape_cells.size(); i++) {
            if (!shape_cells[i].empty()) shape.push_back(stoi(trim(shape_cells[i], "\"")));
          }
          first_line = false;
          continue;
        }
        first_line = false;

        if (delimiter == '\n')
        {
          if (line.empty())
          {
            if (!current_row.empty()) {
              parsed_rows.push_back(current_row);
              current_row.clear();
            }
          }
          else {
            current_row.push_back(trim(line, "\""));
          }
        }
        else
        {
          if (line.empty()) continue;
          vector<string> cells = ppl->processing->SplitCsv(line, delimiter);
          for (auto& c : cells) c = trim(c, "\"");
          parsed_rows.push_back(cells);
        }
      }
      if (!current_row.empty()) parsed_rows.push_back(current_row);
      file.close();

      storage->root.children.clear();

      if (!shape.empty())
      {
        // RESTORE N-DIMENSIONAL ARRAY
        vector<string> flat_data;
        for (const auto& row : parsed_rows) {
          for (const auto& cell : row) {
            // skip empty separator columns only for 3D and higher
            if (shape.size() > 2 && cell.empty()) continue;
            flat_data.push_back(cell);
          }
        }

        int flat_index = 0;
        std::function<void(StorageNode&, int)> BuildNode = [&](StorageNode& curr, int dim_idx) {
          curr.is_leaf = false;
          int count = shape[dim_idx];

          if (dim_idx == shape.size() - 1)
          {
            for (int i = 0; i < count; i++) {
              StorageNode leaf;
              string val = (flat_index < flat_data.size()) ? flat_data[flat_index++] : "0";
              storage->InitNode(leaf, val);
              curr.children.push_back(leaf);
            }
          }
          else
          {
            for (int i = 0; i < count; i++) {
              StorageNode child;
              BuildNode(child, dim_idx + 1);
              curr.children.push_back(child);
            }
          }
          };

        storage->root.is_leaf = false;
        BuildNode(storage->root, 0);
        storage->dimensions_count = shape.size();
      }
      else
      {
        // OLD 1D/2D LOGIC
        if (parsed_rows.empty()) {
          storage->dimensions_count = 1;
        }
        else if (parsed_rows.size() == 1) {
          for (const auto& cell : parsed_rows[0]) {
            StorageNode new_node;
            storage->InitNode(new_node, cell);
            storage->root.children.push_back(new_node);
          }
          storage->dimensions_count = 1;
        }
        else {
          for (const auto& row : parsed_rows) {
            StorageNode row_node;
            row_node.is_leaf = false;
            for (const auto& cell : row) {
              StorageNode cell_node;
              storage->InitNode(cell_node, cell);
              row_node.children.push_back(cell_node);
            }
            storage->root.children.push_back(row_node);
          }
          storage->dimensions_count = 2;
        }
      }
    }

    return true;
  }

}


