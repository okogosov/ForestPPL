ForestPPL examples/MatrixVector/testVector.scr
ForestPPL examples/MatrixVector/testMatrixRow.scr
ForestPPL examples/MatrixVector/testMatrixCol.scr

ForestPPL examples/MatrixVector/SortVector.scr
ForestPPL examples/MatrixVector/SortMatrix.scr