ForestPPL v.2.0.0.4 -- Linux x86-64 (Ubuntu 24.04 / WSL2)
==========================================================

Run
    ./forestppl                                  interactive console
    ./forestppl Examples/StorageLib/TestND.scr   run a script
    ./RunAll.sh                                  run all example scripts, log -> Log.txt
                                                 (about a minute; your Configuration.data is restored afterwards)

Contents
    Forest, libPPL.so, libSyntaxChecker.so, libNotationTransformations.so
    Math.so String.so File.so Directory.so Console.so Convert.so Queue.so Stack.so
    Dictionary.so DataFrame.so Matrix.so Vector.so Random.so Erato.so StorageLib.so
    Configuration.data   which libraries are loaded at start (UserImport lines)
    Functions/ Examples/ Data/   default functions, examples, test data

Notes
    * Run from this folder (or through ./forestppl, which does it for you).
    * Paths in scripts may use "\" or "/"; "examples" and "Examples" both work.
    * Needs libstdc++ from GCC 14 or newer. If Forest says GLIBCXX_3.4.3x not found:
          sudo apt install libstdc++6        (Ubuntu 24.04 is enough)
    * What is new: CHANGES_v2.0.0.4.txt
