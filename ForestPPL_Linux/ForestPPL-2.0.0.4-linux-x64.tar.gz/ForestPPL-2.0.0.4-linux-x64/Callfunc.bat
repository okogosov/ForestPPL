forestPPL Examples/CallFunc/callfunc.scr
forestPPL Examples/CallFunc/func1.scr
rem forestPPL Examples/CallFunc/func2.scr
forestPPL Examples/CallFunc/func3.scr
forestPPL Examples/CallFunc/func4.scr
forestPPL Examples/CallFunc/func5.scr
forestPPL Examples/CallFunc/func8.scr
rem forestPPL Examples/CallFunc/func9.scr     stopped, continue after "exit"
forestPPL Examples/CallFunc/func10.scr
forestPPL Examples/CallFunc/func11.scr
forestPPL Examples/CallFunc/func12.scr
forestPPL Examples/CallFunc/func13.scr
forestPPL Examples/CallFunc/func14.scr
forestPPL Examples/CallFunc/func15.scr
forestPPL Examples/CallFunc/func16.scr
forestPPL Examples/CallFunc/func17.scr
forestPPL Examples/CallFunc/func18.scr
forestPPL Examples/CallFunc/func19.scr
forestPPL Examples/CallFunc/func20.scr
forestPPL Examples/CallFunc/funcarr.scr 
forestPPL Examples/CallFunc/newf.scr
forestPPL Examples/CallFunc/postfix.scr
forestPPL Examples/CallFunc/recursion.scr
forestPPL Examples/CallFunc/Sum.scr

rem tests for parameters: var, Array, storage, struct
forestPPL Examples/CallFunc/test.scr
forestPPL Examples/CallFunc/test2func.scr
forestPPL Examples/CallFunc/testArrayPar.scr
forestPPL Examples/CallFunc/testArrayVarPar.scr
forestPPL Examples/CallFunc/testStorageFunc.scr
forestPPL Examples/CallFunc/testStoragePar.scr
forestPPL Examples/CallFunc/testStoragePar2.scr
forestPPL Examples/CallFunc/testVarPar.scr
forestPPL Examples/CallFunc/testStructPar.scr
