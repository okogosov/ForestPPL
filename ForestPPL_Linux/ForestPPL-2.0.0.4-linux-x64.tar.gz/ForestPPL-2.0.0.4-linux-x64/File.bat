rem ForestPPL examples/Lib/File.scr    >> Log.txt
rem ForestPPL examples/Lib/FileSplit.scr >> Log.txt
rem ForestPPL examples/Lib/FileSplitCsv.scr >> Log.txt
rem ForestPPL examples/Lib/FileSplitCsv2.scr >> Log.txt

ForestPPL examples/Lib/File.scr
ForestPPL examples/Lib/FileSplit.scr
ForestPPL examples/Lib/FileSplitCsv.scr
ForestPPL examples/Lib/FileSplitCsv2.scr