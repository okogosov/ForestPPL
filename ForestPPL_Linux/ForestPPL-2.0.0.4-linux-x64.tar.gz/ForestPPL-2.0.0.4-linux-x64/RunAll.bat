call ArrayFunc.bat > Log.txt
call Callfunc.bat >> Log.txt
call Dataframe.bat >> Log.txt
call Delegates.bat >> Log.txt
call Examples.bat >> Log.txt
call File.bat >> Log.txt
call Math.bat >> Log.txt
call Struct.bat >> Log.txt
call MatrixVector.bat >> Log.txt
call StorageLib.bat >> Log.txt
call Examples.bat >> Log.txt

