forestPPL Examples/ArrayFunc/samples.scr
forestPPL Examples/ArrayFunc/samples2.scr
forestPPL Examples/ArrayFunc/samplesFunc.scr
forestPPL Examples/ArrayFunc/arraycopy.scr
forestPPL Examples/ArrayFunc/arraycsv.scr
forestPPL Examples/ArrayFunc/foreach.scr
forestPPL Examples/ArrayFunc/mean.scr
