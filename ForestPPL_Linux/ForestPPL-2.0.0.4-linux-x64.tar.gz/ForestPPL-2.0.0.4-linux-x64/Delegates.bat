ForestPPL Examples/Delegates/dlgt1.scr
ForestPPL Examples/Delegates/dlgt2.scr
ForestPPL Examples/Delegates/dlgt3.scr
ForestPPL Examples/Delegates/dlgt4.scr
ForestPPL Examples/Delegates/dlgt5.scr
ForestPPL Examples/Delegates/callback.scr