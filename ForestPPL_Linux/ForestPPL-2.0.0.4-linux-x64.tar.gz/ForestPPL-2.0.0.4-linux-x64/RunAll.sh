#!/usr/bin/env bash
# RunAll.sh -- Linux equivalent of RunAll.bat.
#
# This does NOT hardcode the list of test scripts. Instead it actually reads
# RunAll.bat / ArrayFunc.bat / Callfunc.bat / ... (the real .bat files you
# sent, sitting right next to this script) and runs the same "forestPPL
# <script>" lines they contain, in the same order, skipping the same
# commented-out (rem / :: / //) lines. So if you edit a .bat file later,
# RunAll.sh picks up the change automatically -- no need to regenerate it.
#
# Output goes to Log.txt at the repo root, same as on Windows, so you can
# diff it against a Windows-generated Log.txt.
#
# Usage:
#   ./RunAll.sh
#
set -uo pipefail
cd "$(dirname "$0")"

# Two layouts: in the source tree Forest lives in ./build; in a release
# package (Forest + *.so next to this script) it lives right here.
if [ -x ./Forest ] && [ ! -d ./build ]; then BUILD_DIR="."; else BUILD_DIR="build"; fi
LOGFILE="$(pwd)/Log.txt"

# --------------------------------------------------------------------------
# Build if needed
# --------------------------------------------------------------------------
if [ ! -x "$BUILD_DIR/Forest" ]; then
  echo "Forest is not built yet, building now (g++-14 required)..."
  cmake -B "$BUILD_DIR" -DCMAKE_CXX_COMPILER=g++-14 || exit 1
  cmake --build "$BUILD_DIR" -j"$(nproc)" || exit 1
fi

# --------------------------------------------------------------------------
# Forest reads "Configuration.data" from its own working directory, and the
# scripts reference paths like "Examples\..." / "Functions\..." relative to
# that same directory too -- so we run from inside build/, with the runtime
# folders symlinked in from the repo root (kept as the single source of
# truth; edit Examples/Data/Functions at the root, not inside build/).
# --------------------------------------------------------------------------
if [ "$BUILD_DIR" != "." ]; then
for item in Examples Data Log Functions; do
  [ -e "$BUILD_DIR/$item" ] || ln -s "../$item" "$BUILD_DIR/$item"
done
fi
# scripts say "examples/..." (lower case) -- make that work on case-sensitive filesystems
[ -e "$BUILD_DIR/examples" ] || ln -s Examples "$BUILD_DIR/examples" 2>/dev/null || true

# RunAll.bat's own test suite exercises every plugin (Vector, Matrix,
# Dictionary, DataFrame, Queue, Stack, Convert, Random, Erato -- not just
# the 5 enabled in your real Configuration.data), so this run uses a
# dedicated config with all 14 UserImports turned on. Your real
# Configuration.data at the repo root is never touched.
if [ "$BUILD_DIR" = "." ]; then
  # release package: keep the user's Configuration.data, restore it on exit
  cp -f Configuration.data Configuration.data.orig
  trap 'mv -f Configuration.data.orig Configuration.data' EXIT
  cp -f Configuration.RunAll.data Configuration.data
else
  cp Configuration.RunAll.data "$BUILD_DIR/Configuration.data"
fi

: > "$LOGFILE"   # truncate/create, like "call ArrayFunc.bat > Log.txt" at the top of RunAll.bat

# --------------------------------------------------------------------------
# Case-insensitive path resolver.
#
# The .bat files were written for Windows/NTFS, which doesn't care whether
# you write "Examples" or "examples" -- and they don't, inconsistently, even
# within the same file. Linux's ext4 does care. Resolve path components one
# at a time, case-insensitively, so "examples\DataFrame\df1.scr" still finds
# the real "Examples/DataFrame/df1.scr".
# --------------------------------------------------------------------------
resolve_path() {
  local winpath="${1//\\//}"
  local cur="."
  local part
  local old_ifs="$IFS"
  IFS='/'
  for part in $winpath; do
    [ -z "$part" ] && continue
    if [ -e "$cur/$part" ]; then
      cur="$cur/$part"
      continue
    fi
    local match
    # -L: Examples/Data/Functions are symlinked in from the repo root (see
    # above), and plain `find` won't look inside a symlinked directory it's
    # pointed at directly without -L.
    match=$(find -L "$cur" -maxdepth 1 -iname "$part" 2>/dev/null | head -1)
    if [ -z "$match" ]; then
      IFS="$old_ifs"
      return 1
    fi
    cur="$match"
  done
  IFS="$old_ifs"
  printf '%s' "$cur"
}

RAN=0
MISSING=0

run_script() {
  local winpath="$1"
  local resolved
  resolved=$(cd "$BUILD_DIR" && resolve_path "$winpath")
  {
    echo ""
    echo "\$ ./Forest $winpath"
  } >> "$LOGFILE"
  if [ -z "$resolved" ]; then
    echo "Error: [RunAll.sh] script not found: $winpath" >> "$LOGFILE"
    echo "  [MISSING] $winpath"
    MISSING=$((MISSING + 1))
    return
  fi
  echo "  [RUN] $winpath"
  # The known async race (background processing_thread vs. stdin "exit"):
  # a short delay before feeding exit avoids the flaky empty-output case.
  ( cd "$BUILD_DIR" && LD_LIBRARY_PATH=. timeout 30 ./Forest "$resolved" < <(sleep 0.5; echo exit) ) >> "$LOGFILE" 2>&1
  RAN=$((RAN + 1))
}

# Parse one .bat file for active "forestPPL <path>" lines (case-insensitive
# command name; skips rem/::///-commented and blank lines; ignores any other
# command such as "del" in Clean.bat or the dumpbin.exe one-liner in dump.bat
# -- those aren't test invocations).
run_bat_file() {
  local requested="$1"
  local bat
  bat=$(resolve_path "$requested")
  if [ -z "$bat" ]; then
    echo "--- $requested (not found, skipped) ---"
    return
  fi
  echo "--- $bat ---"
  while IFS= read -r line || [ -n "$line" ]; do
    line="${line%$'\r'}"
    local trimmed="${line#"${line%%[![:space:]]*}"}"
    [ -z "$trimmed" ] && continue
    case "$trimmed" in
      rem*|REM*|Rem*|::*|//*) continue ;;
    esac
    local cmd="${trimmed%% *}"
    local cmd_lc="${cmd,,}"
    [ "$cmd_lc" != "forestppl" ] && continue
    local arg="${trimmed#"$cmd"}"
    arg="${arg#"${arg%%[![:space:]]*}"}"
    arg="${arg%"${arg##*[![:space:]]}"}"
    [ -z "$arg" ] && continue
    run_script "$arg"
  done < "$bat"
}

echo "=== RunAll.sh -- Linux equivalent of RunAll.bat ==="
echo "Log: $LOGFILE"
echo

# Mirrors RunAll.bat's call order exactly, with one fix: RunAll.bat itself
# has a typo ("call SorageLib.bat") that doesn't match the real file name
# (StorageLib.bat), so on Windows that line silently does nothing. Fixed
# here so StorageLib actually gets exercised.
for bat in ArrayFunc.bat Callfunc.bat DataFrame.bat Delegates.bat Examples.bat \
           File.bat Math.bat Struct.bat MatrixVector.bat StorageLib.bat Examples.bat; do
  run_bat_file "$bat"
done

echo
echo "=== Done: $RAN script(s) run, $MISSING missing ==="
echo "See $LOGFILE"
