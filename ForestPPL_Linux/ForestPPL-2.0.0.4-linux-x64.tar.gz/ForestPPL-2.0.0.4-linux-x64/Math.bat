rem ForestPPL examples/lib/math.scr  >> Log.txt
ForestPPL examples/lib/math.scr