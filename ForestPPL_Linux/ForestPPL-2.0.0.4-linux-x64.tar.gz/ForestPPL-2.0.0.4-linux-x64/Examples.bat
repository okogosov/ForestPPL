forestPPL Examples/Lib/Queue.scr
forestPPL Examples/Lib/Stack.scr
forestPPL Examples/Lib/Dictionary.scr
forestPPL Examples/Lib/Convert.scr
forestPPL Examples/Lib/File.scr
forestPPL Examples/Lib/Directory.scr
forestPPL Examples/Lib/String.scr
forestPPL Examples/Lib/StringRemove.scr
forestPPL Examples/Lib/WriteFilesInDir.scr
forestPPL Examples/Lib/fileSplit.scr
forestPPL Examples/Lib/Random.scr


forestPPL Examples/ppl/loop.ppl

forestPPL Examples/scr/CopyTo.scr

forestPPL Examples/scr/sieve3.scr
forestPPL examples/scr/erato.scr
forestPPL Examples/scr/gcd.scr

forestPPL Examples/scr/for.ppl
forestPPL Examples/scr/func.scr
forestPPL Examples/scr/func4.scr
forestPPL Examples/scr/writearray.scr

rem forestPPL Examples/Console/colors.scr   
                                         
forestPPL Examples/Access/get_data.ppl
forestPPL Examples/rc/main.scr
rem forestPPL Data/mng2.scr
