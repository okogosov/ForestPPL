del *.exp
del *.map
del *.pdb
del *.txt
